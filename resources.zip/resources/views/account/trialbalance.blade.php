<!-- Page Wrapper -->
@extends('layouts.layout')
@section('pageTitle')
{{env('Page_Title')}}
@endsection
@section('content')
<div class="page-wrapper">
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row">
                <div class="col">

                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Home</a></li>
                        <li class="breadcrumb-item active">Trial Balance</li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- /Page Header -->
        <!-- include notoifcation -->
        @include('_partialView.nofication')
        <!-- /include notoifcation -->
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Trial Balance</h4>
                    </div>
                    <div class="card-body">
                        <form method="post" name="mainform" id="mainform">
                            {{ csrf_field() }}
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label>from</label>
                                            <input type="date" name="fromdate" value="{{$fromdate}}" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label>As at</label>
                                            <input type="date" name="todate" value="{{$todate}}" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label><br></label>
                                            <br>
                                            <button type="submit" class="btn btn-success" name="update"
                                                style="align:left">search</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="table-responsive" style="font-size: 12px;" id="tableData">
                                    <table class="table table-bordered table-striped table-highlight">
                                        <thead>
                                            <tr bgcolor="#c7c7c7">
                                                <th>SN</th>
                                                 <th>Account Name</th>
                                                  <th>Account Number</th>
                                                <th>Debit</th>
                                                <th>Credit</th>
                                            </tr>
                                        </thead>
                                        @php
                                        $Totaldebit=0;
                                        $sn=1;
                                        $Totalcredit=0;
                                        @endphp
                                        @foreach($TrialBal as $data)
                                        <tr>
                                        <td>{{  $sn++}} </td>
                                            <td><a href="/balance-breakdown/{{ $data->accountid}}"
                                                    target="_blank">{{  $data->accountName}}
                                                </a> </td>
                                                 <td>{{  $data->account}} </td>
                                            @if ($data->Credit<0)
                                            <td style="text-align: right; ">
                                                {{number_format(abs($data->Credit),2, '.', ',')}} </td>
                                            <td style="text-align: right; ">0.00</td>
                                            @php $Totaldebit+= $data->Credit; @endphp
                                            @else
                                            <td style="text-align: right; ">0.00</td>
                                            <td style="text-align: right; ">
                                                {{number_format(abs($data->Credit),2, '.', ',')}} </td>

                                            @php $Totalcredit+= $data->Credit; @endphp
                                            @endif
                                        </tr>
                                        @endforeach
                                        <tr>
                                            <td colspan=3>Total</td>
                                            <td style="text-align: right; ">
                                                {{number_format(abs($Totaldebit),2, '.', ',')}} </td>
                                            <td style="text-align: right; ">
                                                {{number_format(abs($Totalcredit),2, '.', ',')}} </td>
                                        </tr>


                                    </table>
                                </div>
                            </div>
                        </form>
                        <button class="hidden-print btn btn-success" id="export">
                                <i class="fa fa-file-excel-o" aria-hidden="true"></i>
                                Export to Excel
                            </button>
                    </div>
                </div>
            </div>
        </div>




    </div>


    @endsection
    @section('scripts')
    
    <script src="//ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
        <script src="//cdn.rawgit.com/rainabba/jquery-table2excel/1.1.0/dist/jquery.table2excel.min.js"></script>

        <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.print.min.js"></script>
    <script>
        const ValidateInput = (id) => {
            document.getElementById(id).value = formatValue(document.getElementById(id).value);
        }

        const formatValue = (val) => {
            return parseFloat(val
                .toString().replace(/\,/g, '')).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        }
        const deleteRecord = (id) => {
            document.getElementById('d-id').value = id;
            $("#delete_modal").modal('show')
        }

        const Reload = (form) => document.forms[form].submit();
         $(function() {
                $("#export").click(function(event) {
                    console.log("Exporting XLS");
                    $("#tableData").table2excel({
                        exclude: ".hidden-print",
                        name: $("#tableData").data("tableName"),
                        filename: "ledger_transaction.xls",
                        preserveColors: false
                    });
                });
            });

    </script>
    @endsection

    @section('styles')
 <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
        <link rel="stylesheet" type="text/css"
            href="https://cdn.datatables.net/buttons/1.5.2/css/buttons.dataTables.min.css">
    @endsection
    <!-- /Page Wrapper -->
