<!-- Page Wrapper -->
@extends('layouts.layout')
@section('pageTitle')
{{env('Page_Title')}}
@endsection
@section('content')
<div class="page-wrapper">
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row">
                <div class="col">
                    <h3 class="page-title">Transaction upload</h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Home</a></li>
                        <li class="breadcrumb-item active">Transaction upload</li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- /Page Header -->
        <!-- include notoifcation -->
        @include('_partialView.nofication')
        <!-- /include notoifcation -->
        <form method="post" name="mainform" id="mainform" onsubmit="disableButton()">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">

                            {{ csrf_field() }}
                            <div class="text-right">

                            </div>
                            <div class="row">

                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Transaction Type </label>

                                        <select class="select2 form-control" name="transactionType" id="transactionType"
                                            onchange='Reload("mainform");'>
                                            <option value="All">--All--</option>
                                            @foreach($transactionTypes as $list)
                                            <option value="{{$list->id}}"
                                                {{$transactionType == (string) $list->id? 'selected':''}}>
                                                {{$list->description}} </option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>From</label>
                                        <input type="date" value="{{$fromDate}}" name="fromDate" class="form-control"
                                            autocomplete="off">

                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>To</label>
                                        <input type="date" value="{{$toDate}}" name="toDate" class="form-control"
                                            autocomplete="off">

                                    </div>
                                </div>

                            </div>
                            <div class="text-right">
                                <button type="submit" class="btn btn-primary">Search</button>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <!-- List of economic code -->
                    <div class="card card-table">
                        <div class="card-header">
                            <h4 class="card-title">Unprocessed Transaction</h4>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover table-center mb-0">
                                    <thead>
                                        <tr>
                                            <th rowspan="1">S/N</th>
                                            <th rowspan="1">Transaction</th>
                                            <th style="text-align: right;">Pending Record</th>
                                            <th style="text-align: right;" >Transaction Amount </th>
                                            <th style="text-align: right;" >Action </th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @php
                                        $sn=1;
                                        $sum_total=0;
                                        $sum_count=0;
            
                                        


                                        @endphp
                                        @foreach($records as $list)
                                        @php
                                        $sum_total +=$list->debit+$list->credit;
                                         $sum_count +=$list->counts;
                                       
                                        @endphp
                                        <tr>
                                            <td>
                                                {{$sn++}}
                                            </td>
                                            <td>
                                                {{$list->description}}
                                            </td>
                                            
                                            <td style="text-align: right;">
                                               
                                                 {{number_format($list->counts,0, '.', ',')}} 
                                            </td>
                                            
                                            <td style="text-align: right;">
                                                {{number_format(($list->debit>0? $list->debit: $list->credit),2, '.', ',')}}

                                            </td>
                                            <td>
                                            
                                           <a class="btn btn-sm bg-danger-light" 
                                               href="javascript: processSingle('{{$list->transaction_type_id}}')" 
                                               {{ $list->group_batch_count > 0 ? 'disabled' : '' }}>
                                               {{ $list->group_batch_count > 0 ? 'Processing...' : 'Process' }}
                                            </a>

                                        </td>
                                            
                                        </tr>
                                        @endforeach
                                        <tr>
                                            <td colspan =2>
                                                Total
                                            </td>

                                            <td style="text-align: right;">
                                               {{number_format($sum_count,0, '.', ',')}} 
                                            </td>
                                            <td style="text-align: right;">
                                                {{number_format($sum_total,2, '.', ',')}}
                                            </td>
                                            
                                        </tr>

                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                    <!-- /List of economic code -->
                    
                </div>
            </div>
        </form>
    </div>


    <!-- Delete Modal -->
    <div class="modal fade" id="process_modal" aria-hidden="true" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <form method="post">
                    {{ csrf_field() }}
                    <div class="modal-body">
                        <div class="form-content p-2">
                            <h4 class="modal-title">Process transaction</h4>
                            <p class="mb-4">Are you sure you want to process this transaction?</p>
                            <button type="submit" class="btn btn-primary" name="process">Continue </button>
                            <input type="hidden" id="transaction-id" name="transactionType">
                            <input type="hidden" value="{{$toDate}}" name="toDate">
                            <input type="hidden" value="{{$fromDate}}" name="fromDate">
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- /Delete Modal -->

</div>


@endsection
@section('scripts')
<script>
    const ValidateInput = (id) => {
        document.getElementById(id).value = parseFloat(document.getElementById(id).value
            .toString().replace(/\,/g, '')).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }
    const deleteRecord = (id) => {
        document.getElementById('d-id').value = id;
        $("#delete_modal").modal('show')
    }
    
    const processSingle = (id) => { 
        document.getElementById('transaction-id').value = id;
        $("#process_modal").modal('show')
    }
    const Upload = () => {

        $("#upload").modal('show')
    }


    const Reload = (form) => document.forms[form].submit();
    
    function disableButton() {
    // document.getElementById("submitBtn").disabled = true;
    document.getElementById("submitBtn").textContent = "Processing, please wait...";
}

</script>
@endsection

@section('styles')

@endsection
<!-- /Page Wrapper -->
