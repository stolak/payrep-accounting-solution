<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use DB;
use App\Http\Traits\AccountTrait;
use App\Http\Traits\AutomatedUploadTrait;
use Auth;
use Carbon\Carbon;

class TransactionProcess implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $fromDate;
    protected $todate;
    protected $transactionType; 
    protected $group_batch;
    protected $user;
   
 /**
     * The number of times the job may be attempted.
     *
     * @var int
     */
   public $tries = 5;

    /**
     * The number of seconds the job can run before timing out.
     *
     * @var int
     */
 public $timeout = 3000; // Increase the timeout period
    /**
     * Create a new job instance.
     *
     * @param mixed $data
     * @return void
     */
    public function __construct($variables)
    {
        $this->fromDate = $variables['fromDate'];
        $this->todate = $variables['todate'];
        $this->transactionType = $variables['transactionType'];
         $this->group_batch = $variables['group_batch'];
         $this->user= $variables['user'];
    }
    /**
     * Execute the job. 
     *
     * @return void
     */
    public function handle()
    {
        //
         set_time_limit(0);
        $beging= "begging". date('H:i:s');
      
       
        

            $defaultSetup = DB::table('account_setups')->get()->toArray();
            $bank_charges = array_filter($defaultSetup, function ($obj) {
                return $obj->id === 6;
            });
            $agent_commission1 = array_filter($defaultSetup, function ($obj) {
                return $obj->id === 6;
            });
            $agent_commission = reset($agent_commission1)->account_id ?? 0;

            $bonus1 = array_filter($defaultSetup, function ($obj) {
                return $obj->id === 7;
            });
            $bonus = reset($bonus1)->account_id ?? 0;

            $aggregator_commission1 = array_filter($defaultSetup, function ($obj) {
                return $obj->id === 8;
            });
            $aggregator_commission = reset($aggregator_commission1)->account_id ?? 0;

            $aggregator_referral1 = array_filter($defaultSetup, function ($obj) {
                return $obj->id === 9;
            });
            $aggregator_referral = reset($aggregator_referral1)->account_id ?? 0;

            $company_commission1 = array_filter($defaultSetup, function ($obj) {
                return $obj->id === 10;
            });
            $company_commission = reset($company_commission1)->account_id ?? 0;

            ///////

            $company_commissionIrecharge1 = array_filter($defaultSetup, function ($obj) {
                return $obj->id === 16;
            });
            $company_commissionIrecharge = reset($company_commissionIrecharge1)->account_id ?? 0;

            $company_commission9pb1 = array_filter($defaultSetup, function ($obj) {
                return $obj->id === 17;
            });
            $company_commission9pb = reset($company_commission9pb1)->account_id ?? 0;

            $company_commissionvfd1 = array_filter($defaultSetup, function ($obj) {
                return $obj->id === 18;
            });
            $company_commissionvfd = reset($company_commissionvfd1)->account_id ?? 0;

            $company_commissionhope1 = array_filter($defaultSetup, function ($obj) {
                return $obj->id === 19;
            });
            $company_commissionhope = reset($company_commissionhope1)->account_id ?? 0;


            //////


            $stamp_duty_account1 = array_filter($defaultSetup, function ($obj) {
                return $obj->id === 13;
            });
            $stamp_duty_account = reset($stamp_duty_account1)->account_id ?? 0;



    $data['records']=$this->data_record($this->transactionType, $this->group_batch);
    
    switch ($this->transactionType) {
                case 1:
                    // do Bank Transfer'
                    foreach ($data['records'] as $record) {
                        
                         
                        try {
                        // Check if agent_account_sub is null, if so, move to the next iteration 
                        if ($record->agent_account_sub === null) {
                            $this->updateFailed($record);
                            continue;
                        }
                        //  dd($record); 
                        $ref = AccountTrait::RefNo();
                        $remarks = "Bank Transfer - $record->account_name";

                        // debit agent wallet with debit amount
                        AccountTrait::debitAccount(
                            $record->agent_account,
                            !is_numeric($record->debits) ? 0 : $record->debits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref,
                            $record->agent_account_sub
                        );

                        // debit agent wallet with fees charge 
                        AccountTrait::creditAccount(
                            $record->agent_account,
                            !is_numeric($record->fees) ? 0 : $record->fees,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref,
                            $record->agent_account_sub
                        );
                        // credit bank with debit amount
                        AccountTrait::creditAccount(
                            $record->account_id,
                            !is_numeric($record->debits) ? 0 : $record->debits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit bank with Bank Charges amount
                        AccountTrait::debitAccount(
                            $record->account_id,
                            !is_numeric($record->bank_charges) ? 0 : $record->bank_charges,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit agent commission payable
                        AccountTrait::debitAccount(
                            $agent_commission,
                            !is_numeric($record->agent_commission) ? 0 : $record->agent_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit bonus payable
                        AccountTrait::debitAccount(
                            $bonus,
                            !is_numeric($record->bonus) ? 0 : $record->bonus,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit aggregator_commission payable
                        AccountTrait::debitAccount(
                            $aggregator_commission,
                            !is_numeric($record->aggregator_commission) ? 0 : $record->aggregator_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit aggregator_referral payable
                        AccountTrait::debitAccount(
                            $aggregator_referral,
                            !is_numeric($record->aggregator_referral) ? 0 : $record->aggregator_referral,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        
                        // credit company_commission payable

                        $company_commission=$company_commission9pb;  
                        
                        if($record->service_provider==='vfd'){
                            $company_commission=$company_commissionvfd;  
                        }
                        if($record->service_provider==='hope'){
                            $company_commission=$company_commissionhope;  
                        }
                        AccountTrait::debitAccount(
                             $company_commission,
                            !is_numeric($record->company_commission) ? 0 : $record->company_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                   
                    } catch (\Exception $e) {

                        DB::table('logs')->insert([
                            'debits' =>$record->debits??0,
                            'credits' =>$record->credits??0,
                            'fees' =>$record->fees??0,
                            'bank_charges' =>$record->bank_charges??0,
                            'agent_commission' =>$record->agent_commission??0,
                            'bonus' =>$record->bonus??0,
                            'aggregator_commission' =>$record->aggregator_commission??0,
                            'aggregator_referral' =>$record->aggregator_referral??0,
                            'company_commission' =>$record->company_commission??0,
                            'account_number' =>$record->account_number??0,
                            'service_provider' =>$record->service_provider??0,
                            'account_name' =>$record->account_name??0,
                            'agent_account' =>$record->agent_account??0,
                            'agent_account_sub' =>$record->agent_account_sub??0,
                            'account_id' =>$record->account_id??0,
                            'formatted_date' =>$record->formatted_date??0,
                            'transaction_type' =>$record->transaction_type??0,
                            ]);
                            $this->updateFailed($record);
                        DB::table('account_transactions')->where('ref', '=', $ref)->delete();
                        
                      }
                      
                      
                    }
 
                    break;
                case 2:
                    // do Bank Transfer Reversal'
                    
                    foreach ($data['records'] as $record) {
                        
                        try {
                        // Check if agent_account_sub is null, if so, move to the next iteration
                        if ($record->agent_account_sub === null) {
                             $this->updateFailed($record);
                            continue;
                        }
                        
                        
                        $fees = $record->bank_charges+  $record->agent_commission+ $record->bonus+$record->aggregator_commission+$record->aggregator_referral+$record->company_commission;
                        
                        $ref = AccountTrait::RefNo();
                        $remarks = "Bank Transfer Reversal  - $record->account_name";

                        //debit agent wallet with debit amount
                        AccountTrait::creditAccount(
                            $record->agent_account,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref,
                            $record->agent_account_sub
                        );

                        // debit agent wallet with fees charge
                        AccountTrait::debitAccount(
                            $record->agent_account,
                            !is_numeric($fees) ? 0 : $fees,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref,
                            $record->agent_account_sub
                        );
                        // credit bank with debit amount
                        AccountTrait::debitAccount(
                            $record->account_id,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit bank with Bank Charges amount
                        AccountTrait::creditAccount(
                            $record->account_id,
                            !is_numeric($record->bank_charges) ? 0 : $record->bank_charges,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit agent commission payable
                        AccountTrait::creditAccount(
                            $agent_commission,
                            !is_numeric($record->agent_commission) ? 0 : $record->agent_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit bonus payable
                        AccountTrait::creditAccount(
                            $bonus,
                            !is_numeric($record->bonus) ? 0 : $record->bonus,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit aggregator_commission payable
                        AccountTrait::creditAccount(
                            $aggregator_commission,
                            !is_numeric($record->aggregator_commission) ? 0 : $record->aggregator_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit aggregator_referral payable
                        AccountTrait::creditAccount(
                            $aggregator_referral,
                            !is_numeric($record->aggregator_referral) ? 0 : $record->aggregator_referral,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit company_commission payable
                        $company_commission=$company_commission9pb;  
                        
                        if($record->service_provider==='vfd'){
                            $company_commission=$company_commissionvfd;  
                        }
                        if($record->service_provider==='hope'){
                            $company_commission=$company_commissionhope;  
                        }
                        AccountTrait::creditAccount(
                            $company_commission,
                            !is_numeric($record->company_commission) ? 0 : $record->company_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // // $this->updateRecord($record, $ref);
                        
                        
                    } catch (\Exception $e) {

                        DB::table('logs')->insert([
                            'debits' =>$record->debits??0,
                            'credits' =>$record->credits??0,
                            'fees' =>$record->fees??0,
                            'bank_charges' =>$record->bank_charges??0,
                            'agent_commission' =>$record->agent_commission??0,
                            'bonus' =>$record->bonus??0,
                            'aggregator_commission' =>$record->aggregator_commission??0,
                            'aggregator_referral' =>$record->aggregator_referral??0,
                            'company_commission' =>$record->company_commission??0,
                            'account_number' =>$record->account_number??0,
                            'service_provider' =>$record->service_provider??0,
                            'account_name' =>$record->account_name??0,
                            'agent_account' =>$record->agent_account??0,
                            'agent_account_sub' =>$record->agent_account_sub??0,
                            'account_id' =>$record->account_id??0,
                            'formatted_date' =>$record->formatted_date??0,
                            'transaction_type' =>$record->transaction_type??0,
                            ]);
                            $this->updateFailed($record);
                        DB::table('account_transactions')->where('ref', '=', $ref)->delete();
                        
                      }
                    }
                    break;
                case 3:
                    // do POS Withdrawal'
                    foreach ($data['records'] as $record) {
                        // Check if agent_account_sub is null, if so, move to the next iteration
                        try {
                        // Check if agent_account_sub is null, if so, move to the next iteration
                        if ($record->agent_account_sub === null) {
                             $this->updateFailed($record);
                            continue;
                        }
                        

                        $ref = AccountTrait::RefNo();
                        $remarks = "POS Withdral - $record->account_name";
                        
                        
                         $fees = $record->bank_charges+  $record->agent_commission+ $record->bonus+$record->aggregator_commission+$record->aggregator_referral+$record->company_commission;
                         
                        //debit agent wallet with debit amount
                        AccountTrait::creditAccount(
                            $record->agent_account,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref,
                            $record->agent_account_sub
                        );

                        // debit agent wallet with fees charge
                        AccountTrait::creditAccount(
                            $record->agent_account,
                            !is_numeric($record->fees) ? 0 : $record->fees,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref,
                            $record->agent_account_sub
                        );
                        // credit bank with debit amount
                        AccountTrait::debitAccount(
                            $record->account_id,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit bank with Bank Charges amount
                        AccountTrait::debitAccount(
                            $record->account_id,
                            !is_numeric($record->bank_charges) ? 0 : $record->bank_charges,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit agent commission payable
                        AccountTrait::debitAccount(
                            $agent_commission,
                            !is_numeric($record->agent_commission) ? 0 : $record->agent_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit bonus payable
                        AccountTrait::debitAccount(
                            $bonus,
                            !is_numeric($record->bonus) ? 0 : $record->bonus,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit aggregator_commission payable
                        AccountTrait::debitAccount(
                            $aggregator_commission,
                            !is_numeric($record->aggregator_commission) ? 0 : $record->aggregator_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit aggregator_referral payable
                        AccountTrait::debitAccount(
                            $aggregator_referral,
                            !is_numeric($record->aggregator_referral) ? 0 : $record->aggregator_referral,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        
                         AccountTrait::debitAccount(
                                    $company_commission,
                                    $record->company_commission,
                                    $ref,
                                    $record->formatted_date,
                                    $remarks,
                                    $this->user,
                                    $ref
                                );
                                //////////////////
                        
                        if($record->credits >= 10000){
                            $stamp_duty= 50;
                            AccountTrait::debitAccount(
                                $stamp_duty_account,
                                $stamp_duty,
                                $ref,
                                $record->formatted_date,
                                $remarks,
                                $this->user,
                                $ref
                            );
                            
                            $comapny_cost = ($fees + 50)- $record->fees;
                            AccountTrait::creditAccount(
                                    $company_commission,
                                   $comapny_cost,
                                    $ref,
                                    $record->formatted_date,
                                    $remarks. "Stamp duty",
                                    $this->user,
                                    $ref
                                );
                        }
                            
                            
                      
                    } catch (\Exception $e) {

                        DB::table('logs')->insert([
                            'debits' =>$record->debits??0,
                            'credits' =>$record->credits??0,
                            'fees' =>$record->fees??0,
                            'bank_charges' =>$record->bank_charges??0,
                            'agent_commission' =>$record->agent_commission??0,
                            'bonus' =>$record->bonus??0,
                            'aggregator_commission' =>$record->aggregator_commission??0,
                            'aggregator_referral' =>$record->aggregator_referral??0,
                            'company_commission' =>$record->company_commission??0,
                            'account_number' =>$record->account_number??0,
                            'service_provider' =>$record->service_provider??0,
                            'account_name' =>$record->account_name??0,
                            'agent_account' =>$record->agent_account??0,
                            'agent_account_sub' =>$record->agent_account_sub??0,
                            'account_id' =>$record->account_id??0,
                            'formatted_date' =>$record->formatted_date??0,
                            'transaction_type' =>$record->transaction_type??0,
                            ]);
                            $this->updateFailed($record);
                        DB::table('account_transactions')->where('ref', '=', $ref)->delete();
                        
                      }
                    }
                    break;
                case 4:
                    // do POS Withdrawal Reversal'
                    foreach ($data['records'] as $record) {
// Check if agent_account_sub is null, if so, move to the next iteration
                       try {
                        // Check if agent_account_sub is null, if so, move to the next iteration
                        if ($record->agent_account_sub === null) {
                             $this->updateFailed($record);
                            continue;
                        }
                        
                        $ref = AccountTrait::RefNo();
                        $remarks = "POS withdral Reversal - $record->account_name";
                        $fees = $record->bank_charges+  $record->agent_commission+ $record->bonus+$record->aggregator_commission+$record->aggregator_referral+$record->company_commission;
                        
                        //debit agent wallet with debit amount
                        AccountTrait::debitAccount(
                            $record->agent_account,
                            !is_numeric($record->debits) ? 0 : $record->debits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref,
                            $record->agent_account_sub
                        );

                        // debit agent wallet with fees charge
                        AccountTrait::debitAccount(
                            $record->agent_account,
                            !is_numeric($record->fees) ? 0 : $record->fees,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref,
                            $record->agent_account_sub
                        );
                        // credit bank with debit amount
                        AccountTrait::creditAccount(
                            $record->account_id,
                            !is_numeric($record->debits) ? 0 : $record->debits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit bank with Bank Charges amount
                        AccountTrait::creditAccount(
                            $record->account_id,
                            !is_numeric($record->bank_charges) ? 0 : $record->bank_charges,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit agent commission payable
                        AccountTrait::creditAccount(
                            $agent_commission,
                            !is_numeric($record->agent_commission) ? 0 : $record->agent_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit bonus payable
                        AccountTrait::creditAccount(
                            $bonus,
                            !is_numeric($record->bonus) ? 0 : $record->bonus,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit aggregator_commission payable
                        AccountTrait::creditAccount(
                            $aggregator_commission,
                            !is_numeric($record->aggregator_commission) ? 0 : $record->aggregator_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit aggregator_referral payable
                        AccountTrait::creditAccount(
                            $aggregator_referral,
                            !is_numeric($record->aggregator_referral) ? 0 : $record->aggregator_referral,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit company_commission payable
                        AccountTrait::creditAccount(
                            $company_commission,
                            !is_numeric($record->company_commission) ? 0 : $record->company_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        if($record->debits >= 10000){
                            $stamp_duty= 50;
                            AccountTrait::creditAccount(
                                $stamp_duty_account,
                                $stamp_duty,
                                $ref,
                                $record->formatted_date,
                                $remarks,
                                $this->user,
                                $ref
                            );
                            
                             $comapny_cost = ($fees + 50)- $record->fees;
                            AccountTrait::debitAccount(
                                    $company_commission,
                                   $comapny_cost,
                                    $ref,
                                    $record->formatted_date,
                                    $remarks. "Stamp duty",
                                    $this->user,
                                    $ref
                                );
                        }
                            
                            
                      
                    } catch (\Exception $e) {

                        DB::table('logs')->insert([
                            'debits' =>$record->debits??0,
                            'credits' =>$record->credits??0,
                            'fees' =>$record->fees??0,
                            'bank_charges' =>$record->bank_charges??0,
                            'agent_commission' =>$record->agent_commission??0,
                            'bonus' =>$record->bonus??0,
                            'aggregator_commission' =>$record->aggregator_commission??0,
                            'aggregator_referral' =>$record->aggregator_referral??0,
                            'company_commission' =>$record->company_commission??0,
                            'account_number' =>$record->account_number??0,
                            'service_provider' =>$record->service_provider??0,
                            'account_name' =>$record->account_name??0,
                            'agent_account' =>$record->agent_account??0,
                            'agent_account_sub' =>$record->agent_account_sub??0,
                            'account_id' =>$record->account_id??0,
                            'formatted_date' =>$record->formatted_date??0,
                            'transaction_type' =>$record->transaction_type??0,
                            ]);
                            $this->updateFailed($record);
                        DB::table('account_transactions')->where('ref', '=', $ref)->delete();
                        
                      }
                        
                        
                    }
                    break;
                case 5:
                    // do IRecharge'
                    foreach ($data['records'] as $record) {
                        try {
                        // Check if agent_account_sub is null, if so, move to the next iteration
                        if ($record->agent_account_sub === null) {
                             $this->updateFailed($record);
                            continue;
                        }
                        $ref = AccountTrait::RefNo();
                        $remarks = "IRecharge - $record->account_name";

                        //debit agent wallet with debit amount
                        AccountTrait::debitAccount(
                            $record->agent_account,
                            !is_numeric($record->debits) ? 0 : $record->debits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref,
                            $record->agent_account_sub
                        );

                        // credit bank with debit amount
                        AccountTrait::creditAccount(
                            $record->account_id,
                            !is_numeric($record->debits) ? 0 : $record->debits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit bank with Bank Charges amount
                        AccountTrait::creditAccount(
                            $record->account_id,
                            !is_numeric($record->bank_charges) ? 0 : $record->bank_charges,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // debit agent wallet with fees charge
                        $fees = $record->agent_commission + $record->bonus + $record->aggregator_commission + $record->aggregator_referral + $record->company_commission;
                        AccountTrait::debitAccount(
                            $record->account_id,
                            $fees,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit agent commission payable
                        AccountTrait::creditAccount(
                            $agent_commission,
                            !is_numeric($record->agent_commission) ? 0 : $record->agent_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit bonus payable
                        AccountTrait::creditAccount(
                            $bonus,
                            !is_numeric($record->bonus) ? 0 : $record->bonus,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit aggregator_commission payable
                        AccountTrait::creditAccount(
                            $aggregator_commission,
                            !is_numeric($record->aggregator_commission) ? 0 : $record->aggregator_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit aggregator_referral payable
                        AccountTrait::creditAccount(
                            $aggregator_referral,
                            !is_numeric($record->aggregator_referral) ? 0 : $record->aggregator_referral,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit company_commission payable
                        AccountTrait::creditAccount(
                            $company_commissionIrecharge,
                            !is_numeric($record->company_commission) ? 0 : $record->company_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                    } catch (\Exception $e) {

                        DB::table('logs')->insert([
                            'debits' =>$record->debits??0,
                            'credits' =>$record->credits??0,
                            'fees' =>$record->fees??0,
                            'bank_charges' =>$record->bank_charges??0,
                            'agent_commission' =>$record->agent_commission??0,
                            'bonus' =>$record->bonus??0,
                            'aggregator_commission' =>$record->aggregator_commission??0,
                            'aggregator_referral' =>$record->aggregator_referral??0,
                            'company_commission' =>$record->company_commission??0,
                            'account_number' =>$record->account_number??0,
                            'service_provider' =>$record->service_provider??0,
                            'account_name' =>$record->account_name??0,
                            'agent_account' =>$record->agent_account??0,
                            'agent_account_sub' =>$record->agent_account_sub??0,
                            'account_id' =>$record->account_id??0,
                            'formatted_date' =>$record->formatted_date??0,
                            'transaction_type' =>$record->transaction_type??0,
                            ]);
                            $this->updateFailed($record);
                        DB::table('account_transactions')->where('ref', '=', $ref)->delete();
                        
                      }
                    }
                    break;
                case 6:
                    // do IRecharge Reversal'
                    foreach ($data['records'] as $record) {
                        try {
                        // Check if agent_account_sub is null, if so, move to the next iteration
                        if ($record->agent_account_sub === null) {
                             $this->updateFailed($record);
                            continue;
                        }
                        $ref = AccountTrait::RefNo();
                        $remarks = "IRecharge Reversal - $record->account_name";

                        //debit agent wallet with debit amount
                        AccountTrait::creditAccount(
                            $record->agent_account,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref,
                            $record->agent_account_sub
                        );

                        // credit bank with debit amount
                        AccountTrait::debitAccount(
                            $record->account_id,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // debit agent wallet with fees charge
                        AccountTrait::creditAccount(
                            $record->account_id,
                            !is_numeric($record->fees) ? 0 : $record->fees,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit bank with Bank Charges amount
                        AccountTrait::debitAccount(
                            $record->account_id,
                            !is_numeric($record->bank_charges) ? 0 : $record->bank_charges,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit agent commission payable
                        AccountTrait::debitAccount(
                            $agent_commission,
                            !is_numeric($record->agent_commission) ? 0 : $record->agent_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit bonus payable
                        AccountTrait::debitAccount(
                            $bonus,
                            !is_numeric($record->bonus) ? 0 : $record->bonus,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit aggregator_commission payable
                        AccountTrait::debitAccount(
                            $aggregator_commission,
                            !is_numeric($record->aggregator_commission) ? 0 : $record->aggregator_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit aggregator_referral payable
                        AccountTrait::debitAccount(
                            $aggregator_referral,
                            !is_numeric($record->aggregator_referral) ? 0 : $record->aggregator_referral,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit company_commission payable
                        AccountTrait::debitAccount(
                            $company_commissionIrecharge,
                            !is_numeric($record->company_commission) ? 0 : $record->company_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        } catch (\Exception $e) {

                        DB::table('logs')->insert([
                            'debits' =>$record->debits??0,
                            'credits' =>$record->credits??0,
                            'fees' =>$record->fees??0,
                            'bank_charges' =>$record->bank_charges??0,
                            'agent_commission' =>$record->agent_commission??0,
                            'bonus' =>$record->bonus??0,
                            'aggregator_commission' =>$record->aggregator_commission??0,
                            'aggregator_referral' =>$record->aggregator_referral??0,
                            'company_commission' =>$record->company_commission??0,
                            'account_number' =>$record->account_number??0,
                            'service_provider' =>$record->service_provider??0,
                            'account_name' =>$record->account_name??0,
                            'agent_account' =>$record->agent_account??0,
                            'agent_account_sub' =>$record->agent_account_sub??0,
                            'account_id' =>$record->account_id??0,
                            'formatted_date' =>$record->formatted_date??0,
                            'transaction_type' =>$record->transaction_type??0,
                            ]);
                            $this->updateFailed($record);
                        DB::table('account_transactions')->where('ref', '=', $ref)->delete();
                        
                      }
                    }
                    break;
                case 7:
                    // do Cash Out'
                    foreach ($data['records'] as $record) {
                       try {
                        // Check if agent_account_sub is null, if so, move to the next iteration
                        if ($record->agent_account_sub === null) {
                             $this->updateFailed($record);
                            continue;
                        }
                        $ref = AccountTrait::RefNo();
                        $remarks = "Cash Out - $record->account_name";

                        //debit agent wallet with debit amount
                        AccountTrait::creditAccount(
                            $record->agent_account,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref,
                            $record->agent_account_sub
                        );

                        // credit bank with debit amount
                        AccountTrait::debitAccount(
                            $record->account_id,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                       } catch (\Exception $e) {

                        DB::table('logs')->insert([
                            'debits' =>$record->debits??0,
                            'credits' =>$record->credits??0,
                            'fees' =>$record->fees??0,
                            'bank_charges' =>$record->bank_charges??0,
                            'agent_commission' =>$record->agent_commission??0,
                            'bonus' =>$record->bonus??0,
                            'aggregator_commission' =>$record->aggregator_commission??0,
                            'aggregator_referral' =>$record->aggregator_referral??0,
                            'company_commission' =>$record->company_commission??0,
                            'account_number' =>$record->account_number??0,
                            'service_provider' =>$record->service_provider??0,
                            'account_name' =>$record->account_name??0,
                            'agent_account' =>$record->agent_account??0,
                            'agent_account_sub' =>$record->agent_account_sub??0,
                            'account_id' =>$record->account_id??0,
                            'formatted_date' =>$record->formatted_date??0,
                            'transaction_type' =>$record->transaction_type??0,
                            ]);
                            $this->updateFailed($record);
                        DB::table('account_transactions')->where('ref', '=', $ref)->delete();
                        
                      }
                    }
                    break;
                case 8:
                    // do KYC'

                    foreach ($data['records'] as $record) {
                       try {
                        // Check if agent_account_sub is null, if so, move to the next iteration
                        if ($record->agent_account_sub === null) {
                             $this->updateFailed($record);
                            continue;
                        }
                        $ref = AccountTrait::RefNo();
                        $remarks = "Cash Out - $record->account_name";

                        //debit agent wallet with debit amount
                        AccountTrait::debitAccount(
                            $record->agent_account,
                            !is_numeric($record->debits) ? 0 : $record->debits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref,
                            $record->agent_account_sub
                        );

                        // credit bank with debit amount
                        AccountTrait::creditAccount(
                            $record->account_id,
                            !is_numeric($record->debits) ? 0 : $record->debits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                       } catch (\Exception $e) {

                        DB::table('logs')->insert([
                            'debits' =>$record->debits??0,
                            'credits' =>$record->credits??0,
                            'fees' =>$record->fees??0,
                            'bank_charges' =>$record->bank_charges??0,
                            'agent_commission' =>$record->agent_commission??0,
                            'bonus' =>$record->bonus??0,
                            'aggregator_commission' =>$record->aggregator_commission??0,
                            'aggregator_referral' =>$record->aggregator_referral??0,
                            'company_commission' =>$record->company_commission??0,
                            'account_number' =>$record->account_number??0,
                            'service_provider' =>$record->service_provider??0,
                            'account_name' =>$record->account_name??0,
                            'agent_account' =>$record->agent_account??0,
                            'agent_account_sub' =>$record->agent_account_sub??0,
                            'account_id' =>$record->account_id??0,
                            'formatted_date' =>$record->formatted_date??0,
                            'transaction_type' =>$record->transaction_type??0,
                            ]);
                            $this->updateFailed($record);
                        DB::table('account_transactions')->where('ref', '=', $ref)->delete();
                        
                      }

                    }
                    break;

                case 9:
                    // do Settlement'
                    foreach ($data['records'] as $record) {
                        try {
                        // Check if agent_account_sub is null, if so, move to the next iteration
                        if ($record->agent_account_sub === null) {
                             $this->updateFailed($record);
                            continue;
                        }
                        $ref = AccountTrait::RefNo();
                        $remarks = "Settlement - $record->account_name";
$fees = $record->bank_charges+  $record->agent_commission+ $record->bonus+$record->aggregator_commission+$record->aggregator_referral+$record->company_commission;
                        
                        //debit agent wallet with debit amount
                        //debit agent wallet with debit amount
                        AccountTrait::creditAccount(
                            $record->agent_account,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref,
                            $record->agent_account_sub
                        );

                        // debit agent wallet with fees charge
                        AccountTrait::creditAccount(
                            $record->agent_account,
                            $fees,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref,
                            $record->agent_account_sub
                        );
                        // credit bank with debit amount
                        AccountTrait::debitAccount(
                            $record->account_id,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit bank with Bank Charges amount
                        AccountTrait::debitAccount(
                            $record->account_id,
                            !is_numeric($record->bank_charges) ? 0 : $record->bank_charges,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit agent commission payable
                        AccountTrait::debitAccount(
                            $agent_commission,
                            !is_numeric($record->agent_commission) ? 0 : $record->agent_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit bonus payable
                        AccountTrait::debitAccount(
                            $bonus,
                            !is_numeric($record->bonus) ? 0 : $record->bonus,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit aggregator_commission payable
                        AccountTrait::debitAccount(
                            $aggregator_commission,
                            !is_numeric($record->aggregator_commission) ? 0 : $record->aggregator_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit aggregator_referral payable
                        AccountTrait::debitAccount(
                            $aggregator_referral,
                            !is_numeric($record->aggregator_referral) ? 0 : $record->aggregator_referral,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        // credit company_commission payable
                        $company_commission=$company_commission9pb;  
                        
                        if($record->service_provider==='vfd'){
                            $company_commission=$company_commissionvfd;  
                        }
                        if($record->service_provider==='hope'){
                            $company_commission=$company_commissionhope;  
                        }
                        AccountTrait::debitAccount(
                            $company_commission,
                            !is_numeric($record->company_commission) ? 0 : $record->company_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        } catch (\Exception $e) {

                        DB::table('logs')->insert([
                            'debits' =>$record->debits??0,
                            'credits' =>$record->credits??0,
                            'fees' =>$record->fees??0,
                            'bank_charges' =>$record->bank_charges??0,
                            'agent_commission' =>$record->agent_commission??0,
                            'bonus' =>$record->bonus??0,
                            'aggregator_commission' =>$record->aggregator_commission??0,
                            'aggregator_referral' =>$record->aggregator_referral??0,
                            'company_commission' =>$record->company_commission??0,
                            'account_number' =>$record->account_number??0,
                            'service_provider' =>$record->service_provider??0,
                            'account_name' =>$record->account_name??0,
                            'agent_account' =>$record->agent_account??0,
                            'agent_account_sub' =>$record->agent_account_sub??0,
                            'account_id' =>$record->account_id??0,
                            'formatted_date' =>$record->formatted_date??0,
                            'transaction_type' =>$record->transaction_type??0,
                            ]);
                            $this->updateFailed($record);
                        DB::table('account_transactions')->where('ref', '=', $ref)->delete();
                        
                      }

                    }
                    break;
                case 10:
                    // do Device Retrieval'
                    foreach ($data['records'] as $record) {
                       try {
                        // Check if agent_account_sub is null, if so, move to the next iteration
                        if ($record->agent_account_sub === null) {
                             $this->updateFailed($record);
                            continue;
                        }

                        $ref = AccountTrait::RefNo();
                        $remarks = "Device Retrieval - $record->account_name";

                        //credit agent wallet with debit amount
                        AccountTrait::creditAccount(
                            $record->agent_account,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref,
                            $record->agent_account_sub
                        );

                        // debit bank with debit amount
                        AccountTrait::debitAccount(
                            $record->account_id,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                       } catch (\Exception $e) {

                        DB::table('logs')->insert([
                            'debits' =>$record->debits??0,
                            'credits' =>$record->credits??0,
                            'fees' =>$record->fees??0,
                            'bank_charges' =>$record->bank_charges??0,
                            'agent_commission' =>$record->agent_commission??0,
                            'bonus' =>$record->bonus??0,
                            'aggregator_commission' =>$record->aggregator_commission??0,
                            'aggregator_referral' =>$record->aggregator_referral??0,
                            'company_commission' =>$record->company_commission??0,
                            'account_number' =>$record->account_number??0,
                            'service_provider' =>$record->service_provider??0,
                            'account_name' =>$record->account_name??0,
                            'agent_account' =>$record->agent_account??0,
                            'agent_account_sub' =>$record->agent_account_sub??0,
                            'account_id' =>$record->account_id??0,
                            'formatted_date' =>$record->formatted_date??0,
                            'transaction_type' =>$record->transaction_type??0,
                            ]);
                            $this->updateFailed($record);
                        DB::table('account_transactions')->where('ref', '=', $ref)->delete();
                        
                      }
                    }
                    break;

                case 11:
                    // do Pos Sales Revenue'
                    foreach ($data['records'] as $record) {
                       try {
                        // Check if agent_account_sub is null, if so, move to the next iteration
                        if ($record->agent_account_sub === null) {
                             $this->updateFailed($record);
                            continue;
                        }
                        $ref = AccountTrait::RefNo();
                        $remarks = "Pos Sales Revenue - $record->account_name";

                        //debit agent wallet with debit amount
                        AccountTrait::creditAccount(
                            $record->agent_account,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref,
                            $record->agent_account_sub
                        );

                        // credit bank with debit amount
                        AccountTrait::debitAccount(
                            $record->account_id,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                    } catch (\Exception $e) {

                        DB::table('logs')->insert([
                            'debits' =>$record->debits??0,
                            'credits' =>$record->credits??0,
                            'fees' =>$record->fees??0,
                            'bank_charges' =>$record->bank_charges??0,
                            'agent_commission' =>$record->agent_commission??0,
                            'bonus' =>$record->bonus??0,
                            'aggregator_commission' =>$record->aggregator_commission??0,
                            'aggregator_referral' =>$record->aggregator_referral??0,
                            'company_commission' =>$record->company_commission??0,
                            'account_number' =>$record->account_number??0,
                            'service_provider' =>$record->service_provider??0,
                            'account_name' =>$record->account_name??0,
                            'agent_account' =>$record->agent_account??0,
                            'agent_account_sub' =>$record->agent_account_sub??0,
                            'account_id' =>$record->account_id??0,
                            'formatted_date' =>$record->formatted_date??0,
                            'transaction_type' =>$record->transaction_type??0,
                            ]);
                            $this->updateFailed($record);
                        DB::table('account_transactions')->where('ref', '=', $ref)->delete();
                        
                      }
                    }
                    break;
                case 12:
                    // do Pos Security Deposit'
                    foreach ($data['records'] as $record) {
                       try {
                        // Check if agent_account_sub is null, if so, move to the next iteration
                        if ($record->agent_account_sub === null) {
                             $this->updateFailed($record);
                            continue;
                        }
                        $ref = AccountTrait::RefNo();
                        $remarks = "Pos Sales Revenue - $record->account_name";

                        //debit agent wallet with debit amount
                        AccountTrait::debitAccount(
                            $record->agent_account,
                            !is_numeric($record->debits) ? 0 : $record->debits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref,
                            $record->agent_account_sub
                        );

                        // credit bank with debit amount
                        AccountTrait::creditAccount(
                            $record->account_id,
                            !is_numeric($record->debits) ? 0 : $record->debits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                       } catch (\Exception $e) {

                        DB::table('logs')->insert([
                            'debits' =>$record->debits??0,
                            'credits' =>$record->credits??0,
                            'fees' =>$record->fees??0,
                            'bank_charges' =>$record->bank_charges??0,
                            'agent_commission' =>$record->agent_commission??0,
                            'bonus' =>$record->bonus??0,
                            'aggregator_commission' =>$record->aggregator_commission??0,
                            'aggregator_referral' =>$record->aggregator_referral??0,
                            'company_commission' =>$record->company_commission??0,
                            'account_number' =>$record->account_number??0,
                            'service_provider' =>$record->service_provider??0,
                            'account_name' =>$record->account_name??0,
                            'agent_account' =>$record->agent_account??0,
                            'agent_account_sub' =>$record->agent_account_sub??0,
                            'account_id' =>$record->account_id??0,
                            'formatted_date' =>$record->formatted_date??0,
                            'transaction_type' =>$record->transaction_type??0,
                            ]);
                            $this->updateFailed($record);
                        DB::table('account_transactions')->where('ref', '=', $ref)->delete();
                        
                      }
                    }
                    break;
                case 14:
                    // do Funding'
                    foreach ($data['records'] as $record) {
                        try {
                        // Check if agent_account_sub is null, if so, move to the next iteration
                        if ($record->agent_account_sub === null) {
                             $this->updateFailed($record);
                            continue;
                        }
                        $ref = AccountTrait::RefNo();
                        $remarks = "Funding - $record->account_name";

                        //credit agent wallet with debit amount
                        AccountTrait::creditAccount(
                            $record->agent_account,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref,
                            $record->agent_account_sub
                        );

                        // credit bank with debit amount
                        AccountTrait::debitAccount(
                            $record->account_id,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                    } catch (\Exception $e) {

                        DB::table('logs')->insert([
                            'debits' =>$record->debits??0,
                            'credits' =>$record->credits??0,
                            'fees' =>$record->fees??0,
                            'bank_charges' =>$record->bank_charges??0,
                            'agent_commission' =>$record->agent_commission??0,
                            'bonus' =>$record->bonus??0,
                            'aggregator_commission' =>$record->aggregator_commission??0,
                            'aggregator_referral' =>$record->aggregator_referral??0,
                            'company_commission' =>$record->company_commission??0,
                            'account_number' =>$record->account_number??0,
                            'service_provider' =>$record->service_provider??0,
                            'account_name' =>$record->account_name??0,
                            'agent_account' =>$record->agent_account??0,
                            'agent_account_sub' =>$record->agent_account_sub??0,
                            'account_id' =>$record->account_id??0,
                            'formatted_date' =>$record->formatted_date??0,
                            'transaction_type' =>$record->transaction_type??0,
                            ]);
                            $this->updateFailed($record);
                        DB::table('account_transactions')->where('ref', '=', $ref)->delete();
                        
                      }
                    }
                    break;
                  case 18:
                    // do Funding reversal'
                    foreach ($data['records'] as $record) {
                        try {
                        // Check if agent_account_sub is null, if so, move to the next iteration
                        if ($record->agent_account_sub === null) {
                             $this->updateFailed($record);
                            continue;
                        }
                        $ref = AccountTrait::RefNo();
                        $remarks = "Funding reversal - $record->account_name";

                        //credit agent wallet with debit amount
                        AccountTrait::debitAccount(
                            $record->agent_account,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref,
                            $record->agent_account_sub
                        );

                        // credit bank with debit amount
                        AccountTrait:: creditAccount(
                            $record->account_id,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                    } catch (\Exception $e) {

                        DB::table('logs')->insert([
                            'debits' =>$record->debits??0,
                            'credits' =>$record->credits??0,
                            'fees' =>$record->fees??0,
                            'bank_charges' =>$record->bank_charges??0,
                            'agent_commission' =>$record->agent_commission??0,
                            'bonus' =>$record->bonus??0,
                            'aggregator_commission' =>$record->aggregator_commission??0, 
                            'aggregator_referral' =>$record->aggregator_referral??0,
                            'company_commission' =>$record->company_commission??0,
                            'account_number' =>$record->account_number??0,
                            'service_provider' =>$record->service_provider??0,
                            'account_name' =>$record->account_name??0,
                            'agent_account' =>$record->agent_account??0,
                            'agent_account_sub' =>$record->agent_account_sub??0,
                            'account_id' =>$record->account_id??0,
                            'formatted_date' =>$record->formatted_date??0,
                            'transaction_type' =>$record->transaction_type??0,
                            ]);
                            $this->updateFailed($record);
                        DB::table('account_transactions')->where('ref', '=', $ref)->delete();
                        
                      }
                    }
                    break;
                case 15:
                    // do Deduction'
                    foreach ($data['records'] as $record) {
                        // Check if agent_account_sub is null, if so, move to the next iteration
                        try {
                        // Check if agent_account_sub is null, if so, move to the next iteration
                        if ($record->agent_account_sub === null) {
                             $this->updateFailed($record);
                            continue;
                        }
                        $ref = AccountTrait::RefNo();
                        $remarks = "Deduction - $record->account_name";

                        //debit agent wallet with debit amount
                        AccountTrait::debitAccount(
                            $record->agent_account,
                            !is_numeric($record->debits) ? 0 : $record->debits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref,
                            $record->agent_account_sub
                        );

                        // credit bank with debit amount
                        AccountTrait::creditAccount(
                            $record->account_id,
                            !is_numeric($record->debits) ? 0 : $record->debits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                        } catch (\Exception $e) {

                        DB::table('logs')->insert([
                            'debits' =>$record->debits??0,
                            'credits' =>$record->credits??0,
                            'fees' =>$record->fees??0,
                            'bank_charges' =>$record->bank_charges??0,
                            'agent_commission' =>$record->agent_commission??0,
                            'bonus' =>$record->bonus??0,
                            'aggregator_commission' =>$record->aggregator_commission??0,
                            'aggregator_referral' =>$record->aggregator_referral??0,
                            'company_commission' =>$record->company_commission??0,
                            'account_number' =>$record->account_number??0,
                            'service_provider' =>$record->service_provider??0,
                            'account_name' =>$record->account_name??0,
                            'agent_account' =>$record->agent_account??0,
                            'agent_account_sub' =>$record->agent_account_sub??0,
                            'account_id' =>$record->account_id??0,
                            'formatted_date' =>$record->formatted_date??0,
                            'transaction_type' =>$record->transaction_type??0,
                            ]);
                            $this->updateFailed($record);
                        DB::table('account_transactions')->where('ref', '=', $ref)->delete();
                        
                      }
                    }
                    break;
                case 16:
                    // do wallet top-up'
                    foreach ($data['records'] as $record) {
                    try {
                        // Check if agent_account_sub is null, if so, move to the next iteration
                        if ($record->agent_account_sub === null) {
                             $this->updateFailed($record);
                            continue;
                        }
                        $ref = AccountTrait::RefNo();
                        $remarks = "wallet top-up - $record->account_name";

                        //credit agent wallet with credit amount
                        AccountTrait::creditAccount(
                            $record->agent_account,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref,
                            $record->agent_account_sub
                        );

                        // credit bank with credit amount
                        AccountTrait::debitAccount(
                            $record->account_id,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref
                        );
                    } catch (\Exception $e) {

                        DB::table('logs')->insert([
                            'debits' =>$record->debits??0,
                            'credits' =>$record->credits??0,
                            'fees' =>$record->fees??0,
                            'bank_charges' =>$record->bank_charges??0,
                            'agent_commission' =>$record->agent_commission??0,
                            'bonus' =>$record->bonus??0,
                            'aggregator_commission' =>$record->aggregator_commission??0,
                            'aggregator_referral' =>$record->aggregator_referral??0,
                            'company_commission' =>$record->company_commission??0,
                            'account_number' =>$record->account_number??0,
                            'service_provider' =>$record->service_provider??0,
                            'account_name' =>$record->account_name??0,
                            'agent_account' =>$record->agent_account??0,
                            'agent_account_sub' =>$record->agent_account_sub??0,
                            'account_id' =>$record->account_id??0,
                            'formatted_date' =>$record->formatted_date??0,
                            'transaction_type' =>$record->transaction_type??0,
                            ]);
                            $this->updateFailed($record);
                        DB::table('account_transactions')->where('ref', '=', $ref)->delete();
                        
                      }
                    }
                    break;
                case 17:
                    // do Wallet Transfer'
                    
                     $data['records']=$this->data_record_wallet($this->transactionType, $this->group_batch);
                    foreach ($data['records'] as $record) {
                       try {
                        // Check if agent_account_sub is null, if so, move to the next iteration
                        if ($record->agent_account_sub === null) {
                             $this->updateFailed($record);
                            continue;
                        }
                        
                        if ($record->receiver_account_sub === null) {
                             $this->updateFailed($record);
                            continue;
                        }
                        $ref = AccountTrait::RefNo();
                        $remarks = "Wallet Transfer - $record->account_name";

                        //credit agent wallet with credit amount
                        AccountTrait::creditAccount(
                            $record->agent_account,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref,
                            $record->agent_account_sub
                        );

                        // debit bank with credit amount
                        AccountTrait::debitAccount(
                            $record->account_id,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref,
                            $record->receiver_account_sub
                        );

                        //debit agent wallet with debit amount
                        AccountTrait::debitAccount(
                            $record->agent_account,
                            !is_numeric($record->debits) ? 0 : $record->debits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref,
                            $record->agent_account_sub
                        );

                        // credit bank with debit amount
                        AccountTrait::creditAccount(
                            $record->account_id,
                            !is_numeric($record->debits) ? 0 : $record->debits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            $this->user,
                            $ref,
                            $record->receiver_account_sub
                        );
                       } catch (\Exception $e) {

                        DB::table('logs')->insert([
                            'debits' =>$record->debits??0,
                            'credits' =>$record->credits??0,
                            'fees' =>$record->fees??0,
                            'bank_charges' =>$record->bank_charges??0,
                            'agent_commission' =>$record->agent_commission??0,
                            'bonus' =>$record->bonus??0,
                            'aggregator_commission' =>$record->aggregator_commission??0,
                            'aggregator_referral' =>$record->aggregator_referral??0,
                            'company_commission' =>$record->company_commission??0,
                            'account_number' =>$record->account_number??0,
                            'service_provider' =>$record->service_provider??0,
                            'account_name' =>$record->account_name??0,
                            'agent_account' =>$record->agent_account??0,
                            'agent_account_sub' =>$record->agent_account_sub??0,
                            'account_id' =>$record->account_id??0,
                            'formatted_date' =>$record->formatted_date??0,
                            'transaction_type' =>$record->transaction_type??0,
                            ]);
                            $this->updateFailed($record);
                        DB::table('account_transactions')->where('ref', '=', $ref)->delete();
                        
                      }
                    }
                    break;
                default:
                    // do something if $variable does not match any of the above cases
                    echo "Default Value ";
            }
            // Increment the start date by 1 day
       
        $this->updateRecord($this->group_batch);
         $beging= "ended " . $this->group_batch;
        DB::table('fstage')->insert([
            'stage_text' => $beging]);
           
    }
    
     public  function data_record($transactionType, $batch)
    { 

            $records = DB::select("SELECT 
            SUM(debit) AS debits,
            SUM(credit) AS credits,
            SUM(fees) AS fees,
            SUM(bank_charges) AS bank_charges,
            SUM(agent_commission) AS agent_commission,
            SUM(bonus) AS bonus,
            SUM(aggregator_commission) AS aggregator_commission,
            SUM(aggregator_referral) AS aggregator_referral,
            SUM(company_commission) AS company_commission,
            account_number,
            MAX(service_provider) AS service_provider,
            MAX(account_name) AS account_name,
            MAX(account_charts_sub.chart_id) AS agent_account,
            MAX(account_charts_sub.id) AS agent_account_sub,
            account_id,
            formatted_date,
            transaction_type
        FROM 
            automated_record
        LEFT JOIN 
            account_charts_sub ON account_charts_sub.accountno = automated_record.account_number
        WHERE 
            process_status = 0
            AND group_batch = '$batch' 
        GROUP BY 
            formatted_date, account_id, account_number, transaction_type, service_provider
        ");
        return $records;
    }
    protected function updateRecord($batch)
    {

        DB::table('automated_record')
            ->where('group_batch', $batch)
            ->update([
                'processed_at' => date('Y-m-d'),
                'process_status' => 1,

            ]);
            
           
    }
    
    protected function updateFailed($record)
    {
           $ref1 = AccountTrait::RefNo();
            
            DB::table('automated_record')
            ->where('formatted_date', $record->formatted_date)
            ->where('account_id', $record->account_id)
            ->where('account_number', $record->account_number)
            ->where('transaction_type', $record->transaction_type)
            ->update([
                'group_batch' =>'0' ,
                'processed_at' => date('Y-m-d'),
                'process_status' => 2, 
                'failed_ref'=>$ref1

            ]);
    }
      public  function data_record_wallet($transactionType, $batch)
    { 

            $records = DB::select("SELECT 
            SUM(debit) AS debits,
            SUM(credit) AS credits,
            SUM(fees) AS fees,
            SUM(bank_charges) AS bank_charges,
            SUM(agent_commission) AS agent_commission,
            SUM(bonus) AS bonus,
            SUM(aggregator_commission) AS aggregator_commission,
            SUM(aggregator_referral) AS aggregator_referral,
            SUM(company_commission) AS company_commission,
            account_number,
            MAX(service_provider) AS service_provider,
            MAX(account_name) AS account_name,
            MAX(main_acc.chart_id) AS agent_account,
            MAX(main_acc.id) AS agent_account_sub,
            
            MAX(receiver_acc.chart_id) AS receiver_account,
            MAX(receiver_acc.id) AS receiver_account_sub,
            
            account_id,
            formatted_date,
            transaction_type, card_account_number
        FROM 
            automated_record
        LEFT JOIN 
            account_charts_sub as main_acc ON main_acc.accountno = automated_record.account_number
         LEFT JOIN 
            account_charts_sub as receiver_acc ON receiver_acc.accountno = automated_record.card_account_number
        WHERE 
            process_status = 0
            AND group_batch = '$batch' 
        GROUP BY 
            formatted_date, account_id, account_number, transaction_type, service_provider, card_account_number
        ");
        return $records;
    }

}

