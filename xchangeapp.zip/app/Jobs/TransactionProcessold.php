<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use DB;
use App\Http\Traits\AccountTrait;
use App\Http\Traits\AutomatedUploadTrait;
use Auth;
use Carbon\Carbon;

class TransactionProcess implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $fromDate;
    protected $todate;
    protected $transactionType;
    protected $group_batch;
   

    /**
     * Create a new job instance.
     *
     * @param mixed $data
     * @return void
     */
    public function __construct($variables)
    {
        set_time_limit(0);
        $this->fromDate = $variables['fromDate'];
        $this->todate = $variables['todate'];
        $this->transactionType = $variables['transactionType'];
         $this->group_batch = $variables['group_batch'];
    }
    /**
     * Execute the job. 
     *
     * @return void
     */
    public function handle()
    {
        //
        $beging= "begging". date('H:i:s');
      
        DB::table('fstage')->insert([
            'stage_text' => $beging]);
            
             DB::table('fstage')->insert([
            'stage_text' => $this->fromDate]);
             DB::table('fstage')->insert([
            'stage_text' => $this->todate]);
             DB::table('fstage')->insert([
            'stage_text' => $this->transactionType]);
        

            $defaultSetup = DB::table('account_setups')->get()->toArray();
            $bank_charges = array_filter($defaultSetup, function ($obj) {
                return $obj->id === 6;
            });
            $agent_commission1 = array_filter($defaultSetup, function ($obj) {
                return $obj->id === 6;
            });
            $agent_commission = reset($agent_commission1)->account_id ?? 0;

            $bonus1 = array_filter($defaultSetup, function ($obj) {
                return $obj->id === 7;
            });
            $bonus = reset($bonus1)->account_id ?? 0;

            $aggregator_commission1 = array_filter($defaultSetup, function ($obj) {
                return $obj->id === 8;
            });
            $aggregator_commission = reset($aggregator_commission1)->account_id ?? 0;

            $aggregator_referral1 = array_filter($defaultSetup, function ($obj) {
                return $obj->id === 9;
            });
            $aggregator_referral = reset($aggregator_referral1)->account_id ?? 0;

            $company_commission1 = array_filter($defaultSetup, function ($obj) {
                return $obj->id === 10;
            });
            $company_commission = reset($company_commission1)->account_id ?? 0;

            ///////

            $company_commissionIrecharge1 = array_filter($defaultSetup, function ($obj) {
                return $obj->id === 16;
            });
            $company_commissionIrecharge = reset($company_commissionIrecharge1)->account_id ?? 0;

            $company_commission9pb1 = array_filter($defaultSetup, function ($obj) {
                return $obj->id === 17;
            });
            $company_commission9pb = reset($company_commission9pb1)->account_id ?? 0;

            $company_commissionvfd1 = array_filter($defaultSetup, function ($obj) {
                return $obj->id === 18;
            });
            $company_commissionvfd = reset($company_commissionvfd1)->account_id ?? 0;

            $company_commissionhope1 = array_filter($defaultSetup, function ($obj) {
                return $obj->id === 19;
            });
            $company_commissionhope = reset($company_commissionhope1)->account_id ?? 0;


            //////


            $stamp_duty_account1 = array_filter($defaultSetup, function ($obj) {
                return $obj->id === 13;
            });
            $stamp_duty_account = reset($stamp_duty_account1)->account_id ?? 0;
 DB::table('fstage')->insert([
            'stage_text' => "is here....."]);

  $start_date = new \DateTime($this->fromDate); 
// End date
$end_date = new \DateTime($this->todate);
 DB::table('fstage')->insert([
            'stage_text' => "is here2....."]);

// Loop through each day in the range

$transaction=1;
while ($start_date <= $end_date) {
    
    DB::table('fstage')->insert([
            'stage_text' => 'Iterated date: '. $start_date->format('Y-m-d')]);
    $data['records']=$this->data_record($this->transactionType, $start_date->format('Y-m-d'), $this->group_batch);
    
     DB::table('fstage')->insert([
            'stage_text' =>'Total record for '.  $this->transactionType. ' ' .$start_date->format('Y-m-d'). ' '. count($data['records'])]); 
    switch ($transaction) {
                case 1:
                    // do Bank Transfer'
                    foreach ($data['records'] as $record) {
                        
                        //  DB::table('logs')->insert([
                        //     'debits' =>$record->debits,
                        //     'credits' =>$record->credits,
                        //     'fees' =>$record->fees,
                        //     'bank_charges' =>$record->bank_charges,
                        //     'agent_commission' =>$record->agent_commission,
                        //     'bonus' =>$record->bonus,
                        //     'aggregator_commission' =>$record->aggregator_commission,
                        //     'aggregator_referral' =>$record->aggregator_referral,
                        //     'company_commission' =>$record->company_commission,
                        //     'account_number' =>$record->account_number,
                        //     'service_provider' =>$record->service_provider,
                        //     'account_name' =>$record->account_name,
                        //     'agent_account' =>$record->agent_account,
                        //     'agent_account_sub' =>$record->agent_account_sub,
                        //     'account_id' =>$record->account_id,
                        //     'formatted_date' =>$record->formatted_date,
                        //     'transaction_type' =>$record->transaction_type,
                        //     ]);
                        try {
                        // Check if agent_account_sub is null, if so, move to the next iteration
                        if ($record->agent_account_sub === null) {
                            continue;
                        }
                        //  dd($record); 
                        $ref = AccountTrait::RefNo();
                        $remarks = "Bank Transfer - $record->account_name";

                        //debit agent wallet with debit amount
                        // AccountTrait::debitAccount(
                        //     $record->agent_account,
                        //     !is_numeric($record->debits) ? 0 : $record->debits,
                        //     $ref,
                        //     $record->formatted_date,
                        //     $remarks,
                        //     Auth::User()->id,
                        //     $ref,
                        //     $record->agent_account_sub
                        // );

                        // // debit agent wallet with fees charge
                        // AccountTrait::debitAccount(
                        //     $record->agent_account,
                        //     !is_numeric($record->fees) ? 0 : $record->fees,
                        //     $ref,
                        //     $record->formatted_date,
                        //     $remarks,
                        //     Auth::User()->id,
                        //     $ref,
                        //     $record->agent_account_sub
                        // );
                        // // credit bank with debit amount
                        // AccountTrait::creditAccount(
                        //     $record->account_id,
                        //     !is_numeric($record->debits) ? 0 : $record->debits,
                        //     $ref,
                        //     $record->formatted_date,
                        //     $remarks,
                        //     Auth::User()->id,
                        //     $ref
                        // );
                        // // credit bank with Bank Charges amount
                        // AccountTrait::creditAccount(
                        //     $record->account_id,
                        //     !is_numeric($record->bank_charges) ? 0 : $record->bank_charges,
                        //     $ref,
                        //     $record->formatted_date,
                        //     $remarks,
                        //     Auth::User()->id,
                        //     $ref
                        // );
                        // // credit agent commission payable
                        // AccountTrait::creditAccount(
                        //     $agent_commission,
                        //     !is_numeric($record->agent_commission) ? 0 : $record->agent_commission,
                        //     $ref,
                        //     $record->formatted_date,
                        //     $remarks,
                        //     Auth::User()->id,
                        //     $ref
                        // );
                        // // credit bonus payable
                        // AccountTrait::creditAccount(
                        //     $bonus,
                        //     !is_numeric($record->bonus) ? 0 : $record->bonus,
                        //     $ref,
                        //     $record->formatted_date,
                        //     $remarks,
                        //     Auth::User()->id,
                        //     $ref
                        // );
                        // // credit aggregator_commission payable
                        // AccountTrait::creditAccount(
                        //     $aggregator_commission,
                        //     !is_numeric($record->aggregator_commission) ? 0 : $record->aggregator_commission,
                        //     $ref,
                        //     $record->formatted_date,
                        //     $remarks,
                        //     Auth::User()->id,
                        //     $ref
                        // );
                        // // credit aggregator_referral payable
                        // AccountTrait::creditAccount(
                        //     $aggregator_referral,
                        //     !is_numeric($record->aggregator_referral) ? 0 : $record->aggregator_referral,
                        //     $ref,
                        //     $record->formatted_date,
                        //     $remarks,
                        //     Auth::User()->id,
                        //     $ref
                        // );
                        
                        // // credit company_commission payable

                        // $company_commission=$company_commission9pb;  
                        
                        // if($record->service_provider==='vfd'){
                        //     $company_commission=$company_commissionvfd;  
                        // }
                        // if($record->service_provider==='hope'){
                        //     $company_commission=$company_commissionhope;  
                        // }
                        // AccountTrait::creditAccount(
                        //      $company_commission,
                        //     !is_numeric($record->company_commission) ? 0 : $record->company_commission,
                        //     $ref,
                        //     $record->formatted_date,
                        //     $remarks,
                        //     Auth::User()->id,
                        //     $ref
                        // );
                        // $this->updateRecord($record, $ref);
                    } catch (\Exception $e) {

                        // DB::table('account_transactions')->where('ref', '=', $ref)->delete();
                        
                      }
                    }
 
                    break;
                case 2:
                    // do Bank Transfer Reversal'
                    
                    foreach ($data['records'] as $record) {
                        // Check if agent_account_sub is null, if so, move to the next iteration
                        if ($record->agent_account_sub === null) {
                            continue;
                        }

                        $ref = AccountTrait::RefNo();
                        $remarks = "Bank Transfer Reversal  - $record->account_name";

                        //debit agent wallet with debit amount
                        AccountTrait::creditAccount(
                            $record->agent_account,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref,
                            $record->agent_account_sub
                        );

                        // debit agent wallet with fees charge
                        AccountTrait::creditAccount(
                            $record->agent_account,
                            !is_numeric($record->fees) ? 0 : $record->fees,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref,
                            $record->agent_account_sub
                        );
                        // credit bank with debit amount
                        AccountTrait::debitAccount(
                            $record->account_id,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // credit bank with Bank Charges amount
                        AccountTrait::debitAccount(
                            $record->account_id,
                            !is_numeric($record->bank_charges) ? 0 : $record->bank_charges,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // credit agent commission payable
                        AccountTrait::debitAccount(
                            $agent_commission,
                            !is_numeric($record->agent_commission) ? 0 : $record->agent_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // credit bonus payable
                        AccountTrait::debitAccount(
                            $bonus,
                            !is_numeric($record->bonus) ? 0 : $record->bonus,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // credit aggregator_commission payable
                        AccountTrait::debitAccount(
                            $aggregator_commission,
                            !is_numeric($record->aggregator_commission) ? 0 : $record->aggregator_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // credit aggregator_referral payable
                        AccountTrait::debitAccount(
                            $aggregator_referral,
                            !is_numeric($record->aggregator_referral) ? 0 : $record->aggregator_referral,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // credit company_commission payable
                        $company_commission=$company_commission9pb;  
                        
                        if($record->service_provider==='vfd'){
                            $company_commission=$company_commissionvfd;  
                        }
                        if($record->service_provider==='hope'){
                            $company_commission=$company_commissionhope;  
                        }
                        AccountTrait::debitAccount(
                            $company_commission,
                            !is_numeric($record->company_commission) ? 0 : $record->company_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        $this->updateRecord($record, $ref);
                    }
                    break;
                case 3:
                    // do POS Withdrawal'
                    foreach ($data['records'] as $record) {
                        // Check if agent_account_sub is null, if so, move to the next iteration
                        if ($record->agent_account_sub === null) {
                            continue;
                        }

                        $ref = AccountTrait::RefNo();
                        $remarks = "POS Withdral - $record->account_name";

                        //debit agent wallet with debit amount
                        AccountTrait::creditAccount(
                            $record->agent_account,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref,
                            $record->agent_account_sub
                        );

                        // debit agent wallet with fees charge
                        AccountTrait::debitAccount(
                            $record->agent_account,
                            !is_numeric($record->fees) ? 0 : $record->fees,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref,
                            $record->agent_account_sub
                        );
                        // credit bank with debit amount
                        AccountTrait::debitAccount(
                            $record->account_id,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // credit bank with Bank Charges amount
                        AccountTrait::creditAccount(
                            $record->account_id,
                            !is_numeric($record->bank_charges) ? 0 : $record->bank_charges,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // credit agent commission payable
                        AccountTrait::creditAccount(
                            $agent_commission,
                            !is_numeric($record->agent_commission) ? 0 : $record->agent_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // credit bonus payable
                        AccountTrait::creditAccount(
                            $bonus,
                            !is_numeric($record->bonus) ? 0 : $record->bonus,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // credit aggregator_commission payable
                        AccountTrait::creditAccount(
                            $aggregator_commission,
                            !is_numeric($record->aggregator_commission) ? 0 : $record->aggregator_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // credit aggregator_referral payable
                        AccountTrait::creditAccount(
                            $aggregator_referral,
                            !is_numeric($record->aggregator_referral) ? 0 : $record->aggregator_referral,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // Handle logic for stamp duuty
                        $stamp_duty= 0;
                        $company_commision_amount= $record->company_commission;
                        if($record->credits >= 10000){
                            $stamp_duty= 50;
                            $company_commision_amount = $record->fees-($record->aggregator_referral + $record->bank_charges+$record->agent_commission+$record->bonus+$record->bonus+$record->aggregator_commission);
                            AccountTrait::creditAccount(
                                $stamp_duty_account,
                                $stamp_duty,
                                $ref,
                                $record->formatted_date,
                                $remarks,
                                Auth::User()->id,
                                $ref
                            );
                        }
                            // credit company_commission payable
                            if($company_commision_amount>0){
                                AccountTrait::creditAccount(
                                    $company_commission,
                                    $company_commision_amount,
                                    $ref,
                                    $record->formatted_date,
                                    $remarks,
                                    Auth::User()->id,
                                    $ref
                                );
                            } else{
                                AccountTrait::debitAccount(
                                    $company_commission,
                                    abs($company_commision_amount),
                                    $ref,
                                    $record->formatted_date,
                                    $remarks,
                                    Auth::User()->id,
                                    $ref
                                );
                            }
                        $this->updateRecord($record, $ref);
                    }
                    break;
                case 4:
                    // do POS Withdrawal Reversal'
                    foreach ($data['records'] as $record) {
// Check if agent_account_sub is null, if so, move to the next iteration
                        if ($record->agent_account_sub === null) {
                            continue;
                        }
                        $ref = AccountTrait::RefNo();
                        $remarks = "POS withdral Reversal - $record->account_name";

                        //debit agent wallet with debit amount
                        AccountTrait::debitAccount(
                            $record->agent_account,
                            !is_numeric($record->debits) ? 0 : $record->debits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref,
                            $record->agent_account_sub
                        );

                        // debit agent wallet with fees charge
                        AccountTrait::creditAccount(
                            $record->agent_account,
                            !is_numeric($record->fees) ? 0 : $record->fees,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref,
                            $record->agent_account_sub
                        );
                        // credit bank with debit amount
                        AccountTrait::creditAccount(
                            $record->account_id,
                            !is_numeric($record->debits) ? 0 : $record->debits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // credit bank with Bank Charges amount
                        AccountTrait::debitAccount(
                            $record->account_id,
                            !is_numeric($record->bank_charges) ? 0 : $record->bank_charges,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // credit agent commission payable
                        AccountTrait::debitAccount(
                            $agent_commission,
                            !is_numeric($record->agent_commission) ? 0 : $record->agent_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // credit bonus payable
                        AccountTrait::debitAccount(
                            $bonus,
                            !is_numeric($record->bonus) ? 0 : $record->bonus,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // credit aggregator_commission payable
                        AccountTrait::debitAccount(
                            $aggregator_commission,
                            !is_numeric($record->aggregator_commission) ? 0 : $record->aggregator_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // credit aggregator_referral payable
                        AccountTrait::debitAccount(
                            $aggregator_referral,
                            !is_numeric($record->aggregator_referral) ? 0 : $record->aggregator_referral,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // credit company_commission payable
                        AccountTrait::debitAccount(
                            $company_commission,
                            !is_numeric($record->company_commission) ? 0 : $record->company_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        $this->updateRecord($record, $ref);
                    }
                    break;
                case 5:
                    // do IRecharge'
                    foreach ($data['records'] as $record) {
                        // Check if agent_account_sub is null, if so, move to the next iteration
                        if ($record->agent_account_sub === null) {
                            continue;
                        }
                        $ref = AccountTrait::RefNo();
                        $remarks = "IRecharge - $record->account_name";

                        //debit agent wallet with debit amount
                        AccountTrait::debitAccount(
                            $record->agent_account,
                            !is_numeric($record->debits) ? 0 : $record->debits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref,
                            $record->agent_account_sub
                        );

                        // credit bank with debit amount
                        AccountTrait::creditAccount(
                            $record->account_id,
                            !is_numeric($record->debits) ? 0 : $record->debits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // credit bank with Bank Charges amount
                        AccountTrait::creditAccount(
                            $record->account_id,
                            !is_numeric($record->bank_charges) ? 0 : $record->bank_charges,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // debit agent wallet with fees charge
                        $fees = $record->agent_commission + $record->bonus + $record->aggregator_commission + $record->aggregator_referral + $record->company_commission;
                        AccountTrait::debitAccount(
                            $record->account_id,
                            $fees,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // credit agent commission payable
                        AccountTrait::creditAccount(
                            $agent_commission,
                            !is_numeric($record->agent_commission) ? 0 : $record->agent_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // credit bonus payable
                        AccountTrait::creditAccount(
                            $bonus,
                            !is_numeric($record->bonus) ? 0 : $record->bonus,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // credit aggregator_commission payable
                        AccountTrait::creditAccount(
                            $aggregator_commission,
                            !is_numeric($record->aggregator_commission) ? 0 : $record->aggregator_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // credit aggregator_referral payable
                        AccountTrait::creditAccount(
                            $aggregator_referral,
                            !is_numeric($record->aggregator_referral) ? 0 : $record->aggregator_referral,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // credit company_commission payable
                        AccountTrait::creditAccount(
                            $company_commissionIrecharge,
                            !is_numeric($record->company_commission) ? 0 : $record->company_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        $this->updateRecord($record, $ref);
                    }
                    break;
                case 6:
                    // do IRecharge Reversal'
                    foreach ($data['records'] as $record) {
                        // Check if agent_account_sub is null, if so, move to the next iteration
                        if ($record->agent_account_sub === null) {
                            continue;
                        }

                        $ref = AccountTrait::RefNo();
                        $remarks = "IRecharge Reversal - $record->account_name";

                        //debit agent wallet with debit amount
                        AccountTrait::creditAccount(
                            $record->agent_account,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref,
                            $record->agent_account_sub
                        );

                        // credit bank with debit amount
                        AccountTrait::debitAccount(
                            $record->account_id,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // debit agent wallet with fees charge
                        AccountTrait::creditAccount(
                            $record->account_id,
                            !is_numeric($record->fees) ? 0 : $record->fees,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // credit bank with Bank Charges amount
                        AccountTrait::debitAccount(
                            $record->account_id,
                            !is_numeric($record->bank_charges) ? 0 : $record->bank_charges,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // credit agent commission payable
                        AccountTrait::debitAccount(
                            $agent_commission,
                            !is_numeric($record->agent_commission) ? 0 : $record->agent_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // credit bonus payable
                        AccountTrait::debitAccount(
                            $bonus,
                            !is_numeric($record->bonus) ? 0 : $record->bonus,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // credit aggregator_commission payable
                        AccountTrait::debitAccount(
                            $aggregator_commission,
                            !is_numeric($record->aggregator_commission) ? 0 : $record->aggregator_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // credit aggregator_referral payable
                        AccountTrait::debitAccount(
                            $aggregator_referral,
                            !is_numeric($record->aggregator_referral) ? 0 : $record->aggregator_referral,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // credit company_commission payable
                        AccountTrait::debitAccount(
                            $company_commissionIrecharge,
                            !is_numeric($record->company_commission) ? 0 : $record->company_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        $this->updateRecord($record, $ref);
                    }
                    break;
                case 7:
                    // do Cash Out'
                    foreach ($data['records'] as $record) {
                        // Check if agent_account_sub is null, if so, move to the next iteration
                        if ($record->agent_account_sub === null) {
                            continue;
                        }
                        $ref = AccountTrait::RefNo();
                        $remarks = "Cash Out - $record->account_name";

                        //debit agent wallet with debit amount
                        AccountTrait::creditAccount(
                            $record->agent_account,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref,
                            $record->agent_account_sub
                        );

                        // credit bank with debit amount
                        AccountTrait::debitAccount(
                            $record->account_id,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        $this->updateRecord($record, $ref);
                    }
                    break;
                case 8:
                    // do KYC'

                    foreach ($data['records'] as $record) {
                        // Check if agent_account_sub is null, if so, move to the next iteration
                        if ($record->agent_account_sub === null) {
                            continue;
                        }
                        $ref = AccountTrait::RefNo();
                        $remarks = "Cash Out - $record->account_name";

                        //debit agent wallet with debit amount
                        AccountTrait::debitAccount(
                            $record->agent_account,
                            !is_numeric($record->debits) ? 0 : $record->debits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref,
                            $record->agent_account_sub
                        );

                        // credit bank with debit amount
                        AccountTrait::creditAccount(
                            $record->account_id,
                            !is_numeric($record->debits) ? 0 : $record->debits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        $this->updateRecord($record, $ref);

                    }
                    break;

                case 9:
                    // do Settlement'
                    foreach ($data['records'] as $record) {
                        // Check if agent_account_sub is null, if so, move to the next iteration
                        if ($record->agent_account_sub === null) {
                            continue;
                        }
                        $ref = AccountTrait::RefNo();
                        $remarks = "Settlement - $record->account_name";

                        //debit agent wallet with debit amount
                        //debit agent wallet with debit amount
                        AccountTrait::creditAccount(
                            $record->agent_account,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref,
                            $record->agent_account_sub
                        );

                        // debit agent wallet with fees charge
                        AccountTrait::creditAccount(
                            $record->agent_account,
                            !is_numeric($record->fees) ? 0 : $record->fees,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref,
                            $record->agent_account_sub
                        );
                        // credit bank with debit amount
                        AccountTrait::debitAccount(
                            $record->account_id,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // credit bank with Bank Charges amount
                        AccountTrait::debitAccount(
                            $record->account_id,
                            !is_numeric($record->bank_charges) ? 0 : $record->bank_charges,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // credit agent commission payable
                        AccountTrait::debitAccount(
                            $agent_commission,
                            !is_numeric($record->agent_commission) ? 0 : $record->agent_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // credit bonus payable
                        AccountTrait::debitAccount(
                            $bonus,
                            !is_numeric($record->bonus) ? 0 : $record->bonus,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // credit aggregator_commission payable
                        AccountTrait::debitAccount(
                            $aggregator_commission,
                            !is_numeric($record->aggregator_commission) ? 0 : $record->aggregator_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // credit aggregator_referral payable
                        AccountTrait::debitAccount(
                            $aggregator_referral,
                            !is_numeric($record->aggregator_referral) ? 0 : $record->aggregator_referral,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        // credit company_commission payable
                        $company_commission=$company_commission9pb;  
                        
                        if($record->service_provider==='vfd'){
                            $company_commission=$company_commissionvfd;  
                        }
                        if($record->service_provider==='hope'){
                            $company_commission=$company_commissionhope;  
                        }
                        AccountTrait::debitAccount(
                            $company_commission,
                            !is_numeric($record->company_commission) ? 0 : $record->company_commission,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        $this->updateRecord($record, $ref);

                    }
                    break;
                case 10:
                    // do Device Retrieval'
                    foreach ($data['records'] as $record) {
                        // Check if agent_account_sub is null, if so, move to the next iteration
                        if ($record->agent_account_sub === null) {
                            continue;
                        }

                        $ref = AccountTrait::RefNo();
                        $remarks = "Device Retrieval - $record->account_name";

                        //credit agent wallet with debit amount
                        AccountTrait::creditAccount(
                            $record->agent_account,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref,
                            $record->agent_account_sub
                        );

                        // debit bank with debit amount
                        AccountTrait::debitAccount(
                            $record->account_id,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        $this->updateRecord($record, $ref);
                    }
                    break;

                case 11:
                    // do Pos Sales Revenue'
                    foreach ($data['records'] as $record) {
                        // Check if agent_account_sub is null, if so, move to the next iteration
                        if ($record->agent_account_sub === null) {
                            continue;
                        }
                        $ref = AccountTrait::RefNo();
                        $remarks = "Pos Sales Revenue - $record->account_name";

                        //debit agent wallet with debit amount
                        AccountTrait::creditAccount(
                            $record->agent_account,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref,
                            $record->agent_account_sub
                        );

                        // credit bank with debit amount
                        AccountTrait::debitAccount(
                            $record->account_id,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        $this->updateRecord($record, $ref);
                    }
                    break;
                case 12:
                    // do Pos Security Deposit'
                    foreach ($data['records'] as $record) {
                        // Check if agent_account_sub is null, if so, move to the next iteration
                        if ($record->agent_account_sub === null) {
                            continue;
                        }
                        $ref = AccountTrait::RefNo();
                        $remarks = "Pos Sales Revenue - $record->account_name";

                        //debit agent wallet with debit amount
                        AccountTrait::debitAccount(
                            $record->agent_account,
                            !is_numeric($record->debits) ? 0 : $record->debits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref,
                            $record->agent_account_sub
                        );

                        // credit bank with debit amount
                        AccountTrait::creditAccount(
                            $record->account_id,
                            !is_numeric($record->debits) ? 0 : $record->debits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        $this->updateRecord($record, $ref);
                    }
                    break;
                case 14:
                    // do Funding'
                    foreach ($data['records'] as $record) {
                        // Check if agent_account_sub is null, if so, move to the next iteration
                        if ($record->agent_account_sub === null) {
                            continue;
                        }
                        $ref = AccountTrait::RefNo();
                        $remarks = "Funding - $record->account_name";

                        //credit agent wallet with debit amount
                        AccountTrait::creditAccount(
                            $record->agent_account,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref,
                            $record->agent_account_sub
                        );

                        // credit bank with debit amount
                        AccountTrait::debitAccount(
                            $record->account_id,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        $this->updateRecord($record, $ref);
                    }
                    break;
                case 15:
                    // do Deduction'
                    foreach ($data['records'] as $record) {
                        // Check if agent_account_sub is null, if so, move to the next iteration
                        if ($record->agent_account_sub === null) {
                            continue;
                        }
                        $ref = AccountTrait::RefNo();
                        $remarks = "Deduction - $record->account_name";

                        //debit agent wallet with debit amount
                        AccountTrait::debitAccount(
                            $record->agent_account,
                            !is_numeric($record->debits) ? 0 : $record->debits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref,
                            $record->agent_account_sub
                        );

                        // credit bank with debit amount
                        AccountTrait::creditAccount(
                            $record->account_id,
                            !is_numeric($record->debits) ? 0 : $record->debits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        $this->updateRecord($record, $ref);
                    }
                    break;
                case 16:
                    // do wallet top-up'
                    foreach ($data['records'] as $record) {
                    // Check if agent_account_sub is null, if so, move to the next iteration
                        if ($record->agent_account_sub === null) {
                            continue;
                        }
                        $ref = AccountTrait::RefNo();
                        $remarks = "wallet top-up - $record->account_name";

                        //credit agent wallet with credit amount
                        AccountTrait::creditAccount(
                            $record->agent_account,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref,
                            $record->agent_account_sub
                        );

                        // credit bank with credit amount
                        AccountTrait::debitAccount(
                            $record->account_id,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        $this->updateRecord($record, $ref);
                    }
                    break;
                case 17:
                    // do Wallet Transfer'
                    foreach ($data['records'] as $record) {
                        // Check if agent_account_sub is null, if so, move to the next iteration
                        if ($record->agent_account_sub === null) {
                            continue;
                        }
                        $ref = AccountTrait::RefNo();
                        $remarks = "Wallet Transfer - $record->account_name";

                        //credit agent wallet with credit amount
                        AccountTrait::creditAccount(
                            $record->agent_account,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref,
                            $record->agent_account_sub
                        );

                        // debit bank with credit amount
                        AccountTrait::debitAccount(
                            $record->account_id,
                            !is_numeric($record->credits) ? 0 : $record->credits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );

                        //debit agent wallet with debit amount
                        AccountTrait::debitAccount(
                            $record->agent_account,
                            !is_numeric($record->debits) ? 0 : $record->debits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref,
                            $record->agent_account_sub
                        );

                        // credit bank with debit amount
                        AccountTrait::creditAccount(
                            $record->account_id,
                            !is_numeric($record->debits) ? 0 : $record->debits,
                            $ref,
                            $record->formatted_date,
                            $remarks,
                            Auth::User()->id,
                            $ref
                        );
                        $this->updateRecord($record, $ref);
                    }
                    break;
                default:
                    // do something if $variable does not match any of the above cases
                    echo "Default Value ";
            }
            // Increment the start date by 1 day
            $start_date->modify('+1 day');
        }
         $beging= "ended ". date('H:i:s');
        DB::table('fstage')->insert([
            'stage_text' => $beging]);
           
    }
    
     protected  function data_record($transactionType,$todate)
    { 

            $records = DB::select("SELECT 
            SUM(debit) AS debits,
            SUM(credit) AS credits,
            SUM(fees) AS fees,
            SUM(bank_charges) AS bank_charges,
            SUM(agent_commission) AS agent_commission,
            SUM(bonus) AS bonus,
            SUM(aggregator_commission) AS aggregator_commission,
            SUM(aggregator_referral) AS aggregator_referral,
            SUM(company_commission) AS company_commission,
            account_number,
            MAX(service_provider) AS service_provider,
            MAX(account_name) AS account_name,
            MAX(account_charts_sub.chart_id) AS agent_account,
            MAX(account_charts_sub.id) AS agent_account_sub,
            account_id,
            formatted_date,
            transaction_type
        FROM 
            automated_record
        LEFT JOIN 
            account_charts_sub ON account_charts_sub.accountno = automated_record.account_number
        WHERE 
            transaction_type_id = '$transactionType'
            AND process_status = 0
            AND formatted_date BETWEEN '$todate' AND '$todate' 
            AND group_batch = '$transactionType'
        GROUP BY 
            formatted_date, account_id, account_number, transaction_type, service_provider
        ");
        return $records;
    }
    protected function updateRecord($record, $ref)
    {

        DB::table('automated_record')
            ->where('formatted_date', $record->formatted_date)
            ->where('account_id', $record->account_id)
            ->where('account_number', $record->account_number)
            ->where('transaction_type', $record->transaction_type)
            ->update([
                'ref_no' => $ref,
                'processed_at' => date('Y-m-d'),
                'process_status' => 1,

            ]);
    }

}

