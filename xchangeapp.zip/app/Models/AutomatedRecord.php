<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class AutomatedRecord extends Model
{
    protected $table = 'automated_record';
    // Fillable fields or use guarded as per your requirements
    protected $fillable = ['group_batch'];
}