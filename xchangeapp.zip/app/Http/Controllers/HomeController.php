<?php

namespace App\Http\Controllers;

use App\Models\Loan;
use App\Models\Customer;
use App\Http\Requests\StoreCustomerRequest;
use App\Http\Requests\UpdateCustomerRequest;
use Illuminate\Http\Request;
use App\Http\Requests;
use DB;
use Auth;
use Carbon\Carbon;
use DateTime;
use Illuminate\Support\Facades\Input;
use Session;
use Illuminate\Support\Facades\URL;
use App\Http\Controllers\Controller;
use App\Http\Traits\SessionTrait;

class HomeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data['activeCustomer']=Customer::where('status',1)->count();
        $data['activeLoans']=Loan::where('status',2)->count();
        $data['applications']=Loan::where('status',0)->count();
        $data['overdue']=Loan::where('amount_outstanding','>',0)->sum('amount_outstanding');
        return view('dashboard', $data);
    }
    
    
    public function checkLastUpdate()
    {
        
        $latest= DB::table('account_transactions')->orderBy('id', 'desc')->value('createdat');
       
        $givenDatetime = $latest;

        // // Convert the given datetime string to a Carbon instance
        // $givenDateTime = Carbon::parse($givenDatetime);
        
        // // Get the current time as a Carbon instance
        // $currentDateTime = Carbon::now();
        
        // // Calculate the difference in minutes
        // $minutesDifference = $currentDateTime->diffInMinutes($givenDateTime);
        
        // // Check if the difference is greater than 3 minutes
        // if ($minutesDifference > 3) {
        // dd("The difference between $latest and $currentDateTime is greater than 3 minutes.\n ");
        // unlink("/home/xchangebox/account.xchangebox.com.ng/queue_worker.lock");
        // } 
       $givenDateTime = Carbon::parse($givenDatetime);

// Get the current time as a Carbon instance
$currentDateTime = Carbon::now();

// Calculate the difference between the given datetime and the current datetime in seconds
$diffInSeconds = $givenDateTime->diffInSeconds($currentDateTime);

// Calculate the desired difference of 4 hours and 3 minutes in seconds
$desiredDiffInSeconds = (4 * 60 * 60) + (3 * 60);

// Check if the difference is greater than the desired difference
if ($diffInSeconds > $desiredDiffInSeconds) {
    echo "The difference $currentDateTime and  $givenDatetime is greater than 4 hours and 3 minutes.\n";
    if (file_exists("/home/xchangebox/account.xchangebox.com.ng/queue_worker.lock")) {
     unlink("/home/xchangebox/account.xchangebox.com.ng/queue_worker.lock");
    exit; // Exit the script if the worker is already running
}
   
} else {
    echo "The difference $currentDateTime and  $givenDatetime is not greater than 4 hours and 3 minutes.\n";
}
        
    }
    
    
    public function index2()
    {
         $data['payslip'] = DB::table('payslip')->where('id',1)->first();
        //  dd($data['payslip']);
        return view('customer.payslip', $data);
    }
    
    // SELECT `id`, `names`, `emp_no`, `Year`, `Month`, `basic`, `housing`, `transportation`, `medical`, `utility`, `tax`, `pension`, `nhf`, `loan`, `position` FROM `payslip` WHERE 1
     public function payslipEntry(Request $request)
    {
        
        if (isset ($_POST['addnew'])) {
            
            $this->validate($request, [
            'names'          => 'required',
            'emp_no'    => 'required',
            'Year'    => 'required',
            'Month'    => 'required',
            'basic'    => 'nullable|numberic',
            'housing'    => 'nullable|numberic',
            'transportation'    => 'nullable|numberic',
            'medical'    => 'nullable|numberic',
            'utility'    => 'nullable|numberic',
            'tax'    => 'nullable|numberic',
            'loan'    => 'nullable|numberic',
            'pension'    => 'nullable|numberic',
            'nhf'    => 'nullable|numberic',
            'position'    => 'required',
          ]);
         $customer = DB::table('payslip')->insertGetId([
        'names' => $request->input('names'),
        'emp_no' => $request->input('emp_no'),
        'Year' => $request->input('Year'),
        'Month' => $request->input('Month'),
        'basic' => $request->input('basic'),
        'housing' => $request->input('housing'),
        'transportation' => $request->input('transportation'),
        'medical' => $request->input('medical'),
        'utility' => $request->input('utility'),
        'tax' => $request->input('tax'),
        'pension' => $request->input('pension'),
        'nhf' => $request->input('nhf'),
        'loan' => $request->input('loan'),
        'position' => $request->input('position')
    ]);
        }
    $data['payslips'] = DB::table('payslip')->get();
        return view('customer.payslip_form', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreCustomerRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreCustomerRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Customer  $customer
     * @return \Illuminate\Http\Response
     */
    public function show(Customer $customer)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Customer  $customer
     * @return \Illuminate\Http\Response
     */
    public function edit(Customer $customer)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateCustomerRequest  $request
     * @param  \App\Models\Customer  $customer
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateCustomerRequest $request, Customer $customer)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Customer  $customer
     * @return \Illuminate\Http\Response
     */
    public function destroy(Customer $customer)
    {
        //
    }
}
