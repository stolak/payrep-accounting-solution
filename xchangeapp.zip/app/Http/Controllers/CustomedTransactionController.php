<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Traits\AccountTrait;
use App\Http\Traits\AutomatedUploadTrait;
use Auth;
use Carbon\Carbon;
use \DateTime;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\URL;
use Session;
use App\Jobs\TransactionProcess;
use App\Http\Traits\SessionTrait;
use App\Models\AutomatedRecord;

class CustomedTransactionController extends Controller
{
    public function __construct()
    {
        define("REGEX", "/[^\d.]/");
        set_time_limit(0);
    }
    function checkNumberFormat($input) {
    // Check if the input contains '(' and ')'
    if (strpos($input, '(') !== false && strpos($input, ')') !== false) {
        return 1; // Contains '(' and ')'
    }
    // Check if the input starts with '-'
    if (strpos($input, '-') === 0) {
        return 1; // Starts with '-'
    }
    // Return 0 if none of the above conditions match
    return 0;
}

function convertDateWithExplode($date) {
    // Split the date string into parts using "/"
    $parts = explode('/', $date);
    
    // Ensure there are exactly 3 parts (dd, mm, yyyy)
    if (count($parts) === 3) {
        // Rearrange parts into YYYY-MM-DD format
        return $parts[2] . '-' . $parts[1] . '-' . $parts[0];
    } else {
        return false; // Return false if the input format is invalid
    }
}
function convertToStandardDate($date) {
    
    $parts = explode('/', $date);
    
    // Ensure there are exactly 3 parts (dd, mm, yyyy)
    if (count($parts) === 3) {
        // Rearrange parts into YYYY-MM-DD format
        if($parts[1]>12){
           return $parts[2] . '-' . $parts[0] . '-' . $parts[1];  
        }
        return $parts[2] . '-' . $parts[1] . '-' . $parts[0];
    }
    
    // Try to parse the date with DateTime::createFromFormat
    $formats = [
        'Y-m-d',      // 2024-11-19
        'd/m/Y',      // 19/11/2024
        'm-d-Y',      // 11-19-2024
        'd M Y',      // 19 Nov 2024
        'M d, Y',     // Nov 19, 2024
        'd/m/y',      // 19/11/24
        'm-d-y',      // 11-19-24
    ];
    try{
        return this-s>formattedDate($date);
        
    } catch (\Exception $e) {
      // do nothing  
    }

    foreach ($formats as $format) {
        try {
          $parsedDate = DateTime::createFromFormat($format, $date);
            if ($parsedDate) {
                return $parsedDate->format('Y-m-d');
            }  
            
        } catch (\Exception $e) {
          // do nothing  
        }
        
    }

    // Final fallback: Try strtotime for generic parsing
    $timestamp = strtotime($date);
    if ($timestamp) {
        return date('Y-m-d', $timestamp);
    }

    // If all fails, return null or handle the error
    return date('Y-m-d');
}
    public function formattedDate($dateStr)
    {

        $date = Carbon::createFromFormat('d/m/Y, H:i:s', $dateStr);

        if ($date) {
            // Format the date in the desired format
            return $date->format('Y-m-d');
        } else {
            return date("Y-m-d");
        }
    }

    public function updateRecord($record, $ref)
    {

        DB::table('automated_record')
            ->where('formatted_date', $record->formatted_date)
            ->where('account_id', $record->account_id)
            ->where('account_number', $record->account_number)
            ->where('transaction_type', $record->transaction_type)
            ->update([
                'ref_no' => $ref,
                'processed_at' => date('Y-m-d'), 
                'process_status' => 1,

            ]);
    }
    public function upload(Request $request)
    {
       

        if (URL::previous() !== URL::current()) {
            $request->session()->forget('transactionType');
        }
        $data['transactionType'] = $request->input('transactionType');
        if ($data['transactionType'] == '') {
            $data['transactionType'] = Session::get('transactionType');
        }
        Session(['transactionType' => $data['transactionType']]);

        $data['toDate'] = $request->input('toDate');
        if ($data['toDate'] == "") {
            $data['toDate'] = date("Y-m-d");
        }

        $data['fromDate'] = $request->input('fromDate');
        if ($data['fromDate'] == "") {
            $data['fromDate'] = date("Y") . '-01-01';
        }

        $data['description'] = $request->input('description');
        if (isset($_POST['upload'])) {
            $this->validate($request, [
                'description' => 'required|string|unique:automated_record,upload_title',
            ]);
            $refno = AccountTrait::RefNo();
            $transactionDetails = DB::table('product_types_text')
                ->leftJoin('product_types', 'product_types.id', 'product_types_text.product_type_id')
                ->select('product_types_text.description', 'product_types.id', 'product_types.account_id')
                ->get()->toArray();

            $mimes = array('application/vnd.ms-excel', 'text/csv', 'text/tsv');
            $file = $_FILES['file']['tmp_name'];
            if (($file == "") || !(in_array($_FILES['file']['type'], $mimes))) {
                return back()->with('error_message', 'Invalid file.');
            } else {

                $handle = fopen($file, "r");
                $c = 0;
                $defaultSetup = DB::table('account_setups')->get()->toArray();
                while (($filesop = fgetcsv($handle, 1000, ",")) !== false) {

                    $dateval = $filesop[0];
                    $accountvalue = $filesop[3];

                    if ($c == 0 || $dateval == "" || $accountvalue == "") {
                        $c = 1;

                    } else {

                        // if (($filesop[16] == 'successful')) {
                            $searchText = $filesop[6];
                            $matchingObjects = array_filter($transactionDetails, function ($obj) use ($searchText) {
                                return $obj->description === $searchText;
                            });
                            $bank_account =reset($matchingObjects)->account_id ?? 0;
                            if((reset($matchingObjects)->id ?? 0)===1){
                           
                            $filesop7=$filesop[7];
                            $bank_account1 = array_filter($defaultSetup, function ($obj) use ($filesop7) {
                                return $obj->particular === $filesop7;
                            });
                            if((reset($bank_account1)->account_id ?? 0)>0){
                                $bank_account=reset($bank_account1)->account_id;
                            }
                            
                            
                        }
                           
                            $filesop11 = preg_replace('/[^\d.]/', '', $filesop[11]);
                            $filesop12 = preg_replace('/[^\d.]/', '', $filesop[12]);
                            $filesop12 = preg_replace('/[^\d.]/', '', $filesop[12]);
                            $filesop13 = preg_replace('/[^\d.]/', '', $filesop[13]);
                            $filesop14 = preg_replace('/[^\d.]/', '', $filesop[14]);
                            
                            $filesop19 = preg_replace('/[^\d.]/', '', $filesop[19]);
                            $filesop20 = preg_replace('/[^\d.]/', '', $filesop[20]);
                            

                            $filesop21 = preg_replace('/[^\d.]/', '', $filesop[21]);

                            $filesop22 = preg_replace('/[^\d.]/', '', $filesop[22]);

                            $filesop23 = preg_replace('/[^\d.]/', '', $filesop[23]);
                            $filesop24 = preg_replace('/[^\d.]/', '', $filesop[24]);
                            try {
                                DB::table('automated_record')->insert([
                                    'trans_date' => $filesop[0],
                                    'serial_number' => $filesop[1], // $transdate,
                                    'account_name' => $filesop[2],
                                    'account_number' => $filesop[3],
                                    'business_name' => $filesop[4],
                                    'card_account_number' => $filesop[5],
                                    'transaction_type' => $filesop[6],
                                    'service_provider' => $filesop[8],
                                    'bank' => $filesop[9],
                                    'beneficiaryname' => $filesop[10],
                                    'debit' => !is_numeric($filesop11) ? 0 : $filesop11,
                                    'credit' => !is_numeric($filesop12) ? 0 : $filesop12,
                                    'balance' => !is_numeric($filesop13) ? 0 : $filesop13,
                                    'fees' => !is_numeric($filesop14) ? 0 : $filesop14,
                                    'terminalID' => $filesop[15],
                                    'rrn' => $filesop[16],
                                    'status' => $filesop[17],
                                    'reference_number' => $filesop[18],
                                    'bank_charges' => !is_numeric($filesop19) ? 0 : $filesop19,
                                    'agent_commission' => !is_numeric($filesop20) ? 0 : $filesop20,
                                    'bonus' => !is_numeric($filesop21) ? 0 : $filesop21,
                                    'aggregator_commission' => !is_numeric($filesop22) ? 0 : $filesop22,
                                    'aggregator_referral' => !is_numeric($filesop23) ? 0 : $filesop23,
                                    'company_commission' => !is_numeric($filesop24) ? 0 : $filesop24,
                                    'process_status' => 0,
                                    'upload_title' => $data['description'],
                                    'upload_batch' => $refno,
                                    'transaction_type_id' => reset($matchingObjects)->id ?? 0,
                                    'account_id' => $bank_account,
                                    'formatted_date' => $this->formattedDate($filesop[0]),
                                    'descriptions' => $request->input('description'),
                                ]);
                            } catch (\Exception $e) {
                                // throw $e;
                                DB::table('failed_transaction_upload')->insert([
                                    'account_number' => $filesop[3],
                                    'system_ref' => $refno,
                                    'file_ref' => $filesop[17],
                                ]);
                            }

                        // }
                    }
                }
            }
            return back()->with('message', 'record successfully updated.');
        }

        $data['records'] =[];// AutomatedUploadTrait::searchUpload($data['transactionType'], $data['fromDate'], $data['toDate'], 0);

        $data['transactionTypes'] = AutomatedUploadTrait::transactionTypes();

        return view('customedTransaction.upload', $data);
    }
    
     public function bankStatement(Request $request)
    {
       

        if (URL::previous() !== URL::current()) {
            $request->session()->forget('transactionType');
        }
        $data['transactionType'] = $request->input('transactionType');
        if ($data['transactionType'] == '') {
            $data['transactionType'] = Session::get('transactionType');
        }
        Session(['transactionType' => $data['transactionType']]);

        $data['toDate'] = $request->input('toDate');
        if ($data['toDate'] == "") {
            $data['toDate'] = date("Y-m-d");
        }

        $data['fromDate'] = $request->input('fromDate');
        if ($data['fromDate'] == "") {
            $data['fromDate'] = date("Y") . '-01-01';
        }

        $data['description'] = $request->input('description');
        if (isset($_POST['upload'])) {
            $this->validate($request, [
                'description' => 'required|string|unique:automated_record,upload_title',
            ]);
            $refno = AccountTrait::RefNo();
            

            $mimes = array('application/vnd.ms-excel', 'text/csv', 'text/tsv');
            $file = $_FILES['file']['tmp_name'];
            if (($file == "") || !(in_array($_FILES['file']['type'], $mimes))) {
                return back()->with('error_message', 'Invalid file.');
            } else {

                $handle = fopen($file, "r");
                $c = 0;
                $defaultSetup = DB::table('account_setups')->get()->toArray();
                while (($filesop = fgetcsv($handle, 1000, ",")) !== false) {

                    $dateval = $filesop[2];
                    $description = $filesop[3];

                    if ($c == 0 || $dateval == "" || $description == "") {
                        $c = 1;

                    } else {

        
                            $filesop0 = preg_replace('/[^\d.]/', '', $filesop[0]);
                            $filesop1 = preg_replace('/[^\d.]/', '', $filesop[1]);
                            $filesop2 = preg_replace('/[^\d.]/', '', $filesop[2]);
                            $filesop3 = preg_replace('/[^\d.]/', '', $filesop[3]);
                            $filesop4 = preg_replace('/[^\d.]/', '', $filesop[4]);
                            
                            $filesop5 = preg_replace('/[^\d.]/', '', $filesop[5]);
                            
                            try {
                                $isCredit= $this->checkNumberFormat($filesop[4]);
                                DB::table('bank_statement')->insert([
                                    // 'transactionDate' => $filesop[0],//$this->convertToStandardDate ($filesop[0]),
                                    'transactionDate' => $this->convertToStandardDate ($filesop[0]),
                                    'accountCode' => $filesop[2],
                                    'description' => $filesop[3],
                                    'debit' => $isCredit>0? 0:$filesop4,
                                    'credit' => $isCredit>0? $filesop4:0,
                                    'batchId' => $refno,
                                    
                                ]);
                            } catch (\Exception $e) {
                                throw $e;
                                // DB::table('failed_transaction_upload')->insert([
                                //     'account_number' => $filesop[3],
                                //     'system_ref' => $refno,
                                //     'file_ref' => $filesop[17],
                                // ]);
                            }

                        // }
                    }
                }
                // dd();
            }
            return back()->with('message', 'record successfully updated.'); 
        }

 if (isset($_POST['process'])) {
     
    $isNotExitAccountNumber= DB::table('bank_statement')
    ->whereNotIn('accountCode', function ($query) {
        $query->select('accountno')
              ->from('account_charts');
    })
    
    ->first();
    if($isNotExitAccountNumber){
        return back()->with('error_message', 'One or more account code is not created.');  
    }
    $transref = AccountTrait::RefNo();
     DB::table('bank_statement')->where('isPosted', 0)->update([
                                    'transactionRef' => $transref,
                                    'isPosted' => 1
                                ]);
    $records = db::table('bank_statement')->where('transactionRef', $transref)
    ->leftJoin('account_charts', 'account_charts.accountno', '=', 'bank_statement.accountCode')->orderBy('bank_statement.id')
    ->select('bank_statement.*', 'account_charts.id as accountId')
    ->get();
    // dd($records);
     $totalCredit=0;
     $totalDebit=0;
     $arrayCredit=[];
     $arrayDebit=[];
     try{
       foreach( $records as $record)
         {
            $totalCredit +=$record->credit;
            $totalDebit +=$record->debit;
            if($record->credit>0) array_push($arrayCredit, $record);
            if($record->debit>0)array_push($arrayDebit, $record);
            
            if($totalCredit===$totalDebit){
                
                 $ref = AccountTrait::RefNo();
                if(count($arrayCredit)>1 && count($arrayDebit)===1){
                   
                    
                    
                    foreach($arrayCredit as $credit){
                    
                    
                    AccountTrait::creditAccount(
                        $arrayDebit[0]->accountId,
                         $credit->credit,
                        $ref,
                        $credit->transactionDate,
                       $credit->description,
                        Auth::User()->id,
                        $transref
                    );
                
                    AccountTrait::debitAccount(
                        $credit->accountId,
                         $credit->credit,
                        $ref,
                        $credit->transactionDate,
                        $credit->description,
                        Auth::User()->id,
                        $transref
                    );
                    
                    // echo "post $credit->accountCode  $credit->credit  $credit->description against ". $arrayDebit[0]->accountCode.'<br>';
                }
                }
                if(count($arrayCredit)===1 && count($arrayDebit)===1){
                    foreach($arrayCredit as $credit){
                        AccountTrait::creditAccount(
                        $arrayDebit[0]->accountId,
                         $credit->credit,
                        $ref,
                        $credit->transactionDate,
                       $credit->description,
                        Auth::User()->id,
                        $transref
                    );
                
                    AccountTrait::debitAccount(
                        $credit->accountId,
                         $credit->credit,
                        $ref,
                        $credit->transactionDate,
                        $credit->description,
                        Auth::User()->id,
                        $transref
                    );
                    // echo "post $credit->accountCode  $credit->credit  $credit->description against".  $arrayDebit[0]->accountCode.'<br>';
                    }
                }
                if(count($arrayCredit)===1 && count($arrayDebit)>1){
                    foreach($arrayDebit as $debit){
                      AccountTrait::debitAccount(
                        $arrayCredit[0]->accountId,
                         $debit->debit,
                        $ref,
                        $debit->transactionDate,
                       $debit->description,
                        Auth::User()->id,
                        $transref
                    );
                
                    AccountTrait::creditAccount(
                        $debit->accountId,
                         $debit->debit,
                        $ref,
                        $debit->transactionDate,
                        $debit->description,
                        Auth::User()->id,
                        $transref
                    );  
                    }
                    
                    
                }
                
                if(count($arrayCredit)>1 && count($arrayDebit)>1){
                  
                    DB::table('bank_statement')->where('transactionRef', $transref)->update([
                        'transactionRef' => null,
                        'isPosted' => 0
                    ]);  
                    
                     DB::table('account_transactions')->where('manual_ref', '=', $transref)->delete();
                     return back()->with('error_message', 'This transaction failed. please the the record and post again.');    
                }
                $totalCredit=0;
                $totalDebit=0;
                $arrayCredit=[];
                $arrayDebit=[];
            }
         }   
     } catch (\Exception $e) {
        DB::table('bank_statement')->where('transactionRef', $transref)->update([
            'transactionRef' => null,
            'isPosted' => 0
        ]);  
        
         DB::table('account_transactions')->where('manual_ref', '=', $transref)->delete();
         return back()->with('error_message', 'This transaction failed. please the the record and post again.');    
     }
    
     if($totalCredit>0 || $totalDebit>0){
         
       DB::table('bank_statement')->where('transactionRef', $transref)->update([
            'transactionRef' => null,
            'isPosted' => 0
        ]);  
        
         DB::table('account_transactions')->where('manual_ref', '=', $transref)->delete();
         return back()->with('error_message', 'This transaction failed. please the the record and post again.');  
     }
      
     
     
 }
        $data['records'] =[];// AutomatedUploadTrait::searchUpload($data['transactionType'], $data['fromDate'], $data['toDate'], 0);
         $data['records'] =db::table('bank_statement')->where('isPosted', 0)
    ->leftJoin('account_charts', 'account_charts.accountno', '=', 'bank_statement.accountCode')->orderBy('bank_statement.id')
    ->select('bank_statement.*', 'account_charts.id as accountId', 'account_charts.accountdescription')
    ->get();

        $data['transactionTypes'] = AutomatedUploadTrait::transactionTypes();

        return view('customedTransaction.bank_statement', $data);
    }

    public function agentupload(Request $request)
    {

        if (URL::previous() !== URL::current()) {
            $request->session()->forget('transactionType');
        }

        $data['asat'] = $request->input('asat');

        $data['toDate'] = $request->input('toDate');
        if ($data['toDate'] == "") {
            $data['toDate'] = date("Y-m-d");
        }

        $data['fromDate'] = $request->input('fromDate');
        if ($data['fromDate'] == "") {
            $data['fromDate'] = date("Y") . '-01-01';
        }
       
        if (isset($_POST['upload'])) {
            $this->validate($request, [
                'asat' => 'required|string',
            ]);
            $refno = AccountTrait::RefNo();
            $agentPayable = DB::table('account_setups')
            ->where('id', 11)
            ->value('account_id');
            $agentWalletId = DB::table('account_setups')
            ->where('id', 12)
            ->value('account_id');
            $agentWallet =DB::table('account_charts')->where('id', $agentWalletId)->first();
            
            $confirmagentPayable =DB::table('account_charts')->where('id', $agentPayable)->first();
            if (!$agentWallet) {

                return back()->with('error_message', ' Make sure setup account for agent wallet');
            }
            if (!$confirmagentPayable) {

                return back()->with('error_message', ' Make sure setup account for agent payable');
            }

            $mimes = array('application/vnd.ms-excel', 'text/csv', 'text/tsv');
            $file = $_FILES['file']['tmp_name'];
            if (($file == "") || !(in_array($_FILES['file']['type'], $mimes))) {
                return back()->with('error_message', 'Invalid file.');
            } else {

                $handle = fopen($file, "r");
                $c = 0;
                $subheadid = DB::table('setup_subheads')->where('id', 3)->value('subhead_id');
                while (($filesop = fgetcsv($handle, 1000, ",")) !== false) {

                    $accountvalue = $filesop[2];
                    $ref = AccountTrait::RefNo();
                    if ($c == 0 || $accountvalue == "") {
                        $c = 1;

                    } else {
                        try {
                            $string = mb_convert_encoding($filesop[1], 'UTF-8', 'UTF-8');
                            $filesop1= (preg_replace('/[^\PC\s]/u', '',$string));
                            
                            $string = mb_convert_encoding($filesop[3], 'UTF-8', 'UTF-8');
                            $filesop3= (preg_replace('/[^\PC\s]/u', '',$string));


                            $filesop4 = (float) str_replace(',', '',  $filesop[4]);


                            $id = DB::table('agents')->insertGetId([
                                'agent_name' => $filesop1,
                                'account_ref' => $filesop[2],
                                'business_name' =>$filesop3,
                                'opening_bal' => !is_numeric($filesop4) ? 0 : $filesop4,
                                'as_at' => $request->input('asat'),

                            ]);

                           

                           
                                $account = DB::table('account_charts_sub')->insertGetId([
                                    'groupid' => $agentWallet->groupid,
                                    'chart_id' => $agentWallet->id,
                                    'headid' => $agentWallet->headid,
                                    'subheadid' => $agentWallet->subheadid,
                                    'accountno' => $filesop[2],
                                    'accountdescription' => $filesop1,
                                    'status' => 1,
                                    'rank' => 0,
                                ]);
                                DB::table('agents')->where('id', $id)->update([
                                    'account_id' => $account,
                                ]);
if(floatval($filesop4)<0){
    AccountTrait::debitAccount(
        $agentPayable,
        abs( $filesop4),
        $ref,
        $request->input('asat'),
        $filesop1 . 'Opening Balance',
        Auth::User()->id,
        $ref
    );

    AccountTrait::creditAccount(
        $agentWalletId,
        abs( $filesop4),
        $ref,
        $request->input('asat'),
        $filesop1 . 'Opening Balance',
        Auth::User()->id,
        $ref,
        $account
    );
    
}else{

AccountTrait::creditAccount(
        $agentPayable,
        abs( $filesop4),
        $ref,
        $request->input('asat'),
        $filesop1 . ' Opening Balance',
        Auth::User()->id,
        $ref
    );

    AccountTrait::debitAccount(
        $agentWalletId,
        abs( $filesop4),
        $ref,
        $request->input('asat'),
        $filesop1. 'Opening Balance',
        Auth::User()->id,
        $ref,
        $account
    );
    
}
                               

                            
                        } catch (\Exception $e) {
                           
                            DB::table('failed_agent_upload')->insertGetId([
                                'account_number' => $filesop[2],
                                'system_ref' => $refno,
                            ]);
                            DB::table('account_transactions')->where('ref', '=', $ref)->delete();
                           

                        }

                    }
                }
            }
            return back()->with('message', 'record successfully updated.');
        }

        $data['records'] = AutomatedUploadTrait::agentsList( $data['toDate'], $data['fromDate']);

        return view('customedTransaction.agentUpload', $data);
    }

    public function ProcessUpload(Request $request)
    {

        if (URL::previous() !== URL::current()) {
            $request->session()->forget('transactionType');
        }
        
       $data['transactionType']= SessionTrait::validate($request, 'transactionType');
        

  
        $data['toDate']= SessionTrait::validate($request, 'toDate');
        if ($data['toDate'] == "") {
            $data['toDate'] = date("Y-m-d");
        }

$data['fromDate']= SessionTrait::validate($request, 'fromDate');
        if ($data['fromDate'] == "") {
            $data['fromDate'] = date("Y-m") . '-01';
        }


        $data['description'] = $request->input('description');
        $todate= $data['toDate'];
         $fromDate= $data['fromDate'];
          $transactionType= $data['transactionType'];


  $data['records']=DB::table('automated_record')
    ->leftJoin('product_types', 'product_types.id', '=', 'automated_record.transaction_type_id')
    ->select(
        DB::raw('COUNT(*) as counts')
        , DB::raw('SUM(credit) as credit')
        , DB::raw('SUM(debit) as debit')
        , DB::raw('SUM(CASE WHEN group_batch != "0" THEN 1 ELSE 0 END) as group_batch_count')
        , 'product_types.description'
        , 'transaction_type_id'
    )
    ->where('process_status', '=', 0)
    ->whereBetween('formatted_date', [$data['fromDate'],  $data['toDate']])
    ->groupBy('transaction_type_id', 'product_types.description')
    
    ->get();

        if (isset($_POST['process'])) {
           $variables = ['fromDate' => $fromDate, 'todate'=> $data['toDate'], 'transactionType'=> $data['transactionType']];
                // Dispatch the job
                // TransactionProcess::dispatch($variables);
                
              

// Query the records in chunks with condition and order
$pendingRecord= DB::table('automated_record')->where('process_status', 0)->where('group_batch', 0)->where('transaction_type_id', $data['transactionType']) ->whereBetween('formatted_date', [$data['fromDate'],  $data['toDate']])->first(); 
//  dd($pendingRecord);
while($pendingRecord){
     $ref = AccountTrait::RefNo();
    //  dd($ref);
    DB::table('automated_record')
    ->where('process_status', 0)
   ->where('group_batch', '0')
    ->where('transaction_type_id', $data['transactionType'])
    ->whereBetween('formatted_date', [$data['fromDate'],  $data['toDate']])
    ->limit(10000)
    ->update(['group_batch' => $ref]);
      $variables = ['fromDate' => $data['fromDate'], 'todate'=> $data['toDate'], 'transactionType'=> $data['transactionType'], 'group_batch'=>$ref, 'user'=>Auth::User()->id];
       TransactionProcess::dispatch($variables);
    $pendingRecord= DB::table('automated_record')->where('process_status', 0)->where('group_batch', 0)->where('transaction_type_id', $data['transactionType']) ->whereBetween('formatted_date', [$data['fromDate'],  $data['toDate']])->first();
}

            
            return back()->with('message', 'record successfully process.');
        }

        $data['transactionTypes'] = AutomatedUploadTrait::transactionTypes();

        return view('customedTransaction.process_uploads2', $data);
    }

    public function viewGroupUpoad(Request $request)
    {

        if (URL::previous() !== URL::current()) {
            $request->session()->forget('transactionType');
        }
        $data['transactionType'] = $request->input('transactionType');
        if ($data['transactionType'] == '') {
            $data['transactionType'] = Session::get('transactionType');
        }
        Session(['transactionType' => $data['transactionType']]);

        $data['toDate'] = $request->input('toDate');
        if ($data['toDate'] == "") {
            $data['toDate'] = date("Y-m-d");
        }

        $data['fromDate'] = $request->input('fromDate');
        if ($data['fromDate'] == "") {
            $data['fromDate'] = date("Y") . '-01-01';
        }

        $data['description'] = $request->input('description');
        

        // $data['records'] = AutomatedUploadTrait::searchUpload('', $data['fromDate'], $data['toDate'], 0);

        $data['records'] = DB::table('automated_record')
       
        ->select(
           
            'descriptions', 'upload_batch',
            DB::raw('MAX(`process_status`) as max_process_status'), 
            DB::raw('MAX(`formatted_date`) as max_formatted_date'),
            DB::raw('MIN(`process_status`) as min_process_status'), 
            DB::raw('MIN(`formatted_date`) as min_formatted_date'),
            DB::raw('sum(`debit`) as debits'),
            DB::raw('sum(`credit`) as credits'),
            DB::raw('sum(`fees`) as fees'),
             DB::raw('count(*) as counts')
           
        )
        
        ->groupBy('descriptions', 'upload_batch')
        ->get();
       

        $data['transactionTypes'] = AutomatedUploadTrait::transactionTypes(); 

        return view('customedTransaction.view-group-upload', $data);
    }
    public function uploadDetails(Request $request, $id)
    {

        if (URL::previous() !== URL::current()) {
            $request->session()->forget('transactionType');
        }
        $data['transactionType'] = $request->input('transactionType');
        if ($data['transactionType'] == '') {
            $data['transactionType'] = Session::get('transactionType');
        }
        Session(['transactionType' => $data['transactionType']]);

        if (isset($_POST['delete'] ) ) {
            if(DB::table('automated_record')
            ->where('id', '=', $request->input('id'))
            ->where('process_status', '=', 0)          
            ->delete())
            return back()->with('message', ' Record successfully trashed.');
            return back()->with('error_message', ' Action not perform! it is either the record have been processed or deleted.');
        }
       
        if (isset($_POST['modify'] ) ) {
            $defaultSetup = DB::table('account_setups')->get()->toArray();
                        $filesop7=$request->input('provider');
                            $bank_account1 = array_filter($defaultSetup, function ($obj) use ($filesop7) {
                                return $obj->particular === $filesop7;
                            });
                            
                            $bank_account=reset($bank_account1)->account_id??0;
                            
            if(DB::table('automated_record')
            ->where('id', '=', $request->input('id'))
            ->where('process_status', '=', 0)
            ->update(['service_provider' => $request->input('provider'),
            'account_id' => $bank_account]))
            return back()->with('message', ' Record successfully trashed.');
            return back()->with('error_message', ' Action not perform! it is either the record have been processed or deleted.');
        }
       

        $data['records'] = AutomatedUploadTrait::uploadDetails($id,  $request->input('transactionType'));

        $data['transactionTypes'] = AutomatedUploadTrait::transactionTypes();

        return view('customedTransaction.upload-details', $data);
    } 
    
    public function balanceUpload(Request $request)
    {

    //   dd("Not allowed");
       $files= DB::table('june_2024_trial_balance_upload')->where('status', 0)->get();
       
            
           $agentPayable = DB::table('account_setups')
            ->where('id', 11) ->value('account_id');

        
                foreach($files as $ledger) {

                    // dd($ledger);
                    $ref = AccountTrait::RefNo();
                    
                        try {
                           
 $agentWalletId= DB::table('account_charts')->where('accountno',$ledger->AccountCode)->value('id');  
                               
if(floatval($ledger->amount)<0){
    AccountTrait::creditAccount(
        $agentPayable,
        abs( $ledger->amount),
        $ref,
       '2024-06-30',
        $ledger->Name . ' Opening Balance',
        Auth::User()->id,
        $ref
    );
// dd($agentWalletId);
    AccountTrait::debitAccount(
        $agentWalletId,
        abs( $ledger->amount),
        $ref,
        '2024-06-30',
        $ledger->Name. 'Opening Balance',
        Auth::User()->id,
        $ref
    );
}else{

    AccountTrait::debitAccount(
        $agentPayable,
        abs( $ledger->amount),
        $ref,
        '2024-06-30',
        $ledger->Name . 'Opening Balance',
        Auth::User()->id,
        $ref
    );

    AccountTrait::creditAccount(
        $agentWalletId,
        abs( $ledger->amount),
        $ref,
        '2024-06-30',
        $ledger->Name . 'Opening Balance',
        Auth::User()->id,
        $ref
        
    );
}
                               

                    DB::table('june_2024_trial_balance_upload')->where('id', $ledger->id)->update(['status' => 1]);
                            
                        } catch (\Exception $e) {
                            // dd($e);
                           
                            DB::table('account_transactions')->where('ref', '=', $ref)->delete();
                           

                        }

                    }
                
            dd("final");
            
      

        
    }

  public function data_record($transactionType,$todate)
    {

            $records = DB::select("SELECT 
            SUM(debit) AS debits,
            SUM(credit) AS credits,
            SUM(fees) AS fees,
            SUM(bank_charges) AS bank_charges,
            SUM(agent_commission) AS agent_commission,
            SUM(bonus) AS bonus,
            SUM(aggregator_commission) AS aggregator_commission,
            SUM(aggregator_referral) AS aggregator_referral,
            SUM(company_commission) AS company_commission,
            account_number,
            MAX(service_provider) AS service_provider,
            MAX(account_name) AS account_name,
            MAX(account_charts_sub.chart_id) AS agent_account,
            MAX(account_charts_sub.id) AS agent_account_sub,
            account_id,
            formatted_date,
            transaction_type
        FROM 
            automated_record
        LEFT JOIN 
            account_charts_sub ON account_charts_sub.accountno = automated_record.account_number
        WHERE 
            transaction_type_id = '$transactionType'
            AND process_status = 0
            AND formatted_date BETWEEN '$todate' AND '$todate' 
        GROUP BY 
            formatted_date, account_id, account_number, transaction_type, service_provider
        ");
        return $records;
    }
    
     public function viewGroupFailedUpoad(Request $request)
    {

       
       
       DB::table('failed_transaction_upload')->where('system_ref', '=', $request->input('id'))->delete();

        $data['records'] = DB::table('failed_transaction_upload')
        ->select(
            DB::raw('MAX(`created_at`) as created_at'), 
            DB::raw('count(*) as counts')
            ,'system_ref'
           
        )
        
        ->groupBy('system_ref')
        ->get();

         

        return view('customedTransaction.view-failed-group-upload', $data);
    }
    
     public function viewFailedUpoads(Request $request, $id)
    {

       

        $data['records'] = DB::table('failed_transaction_upload')
        ->where('system_ref',$id)
        ->get();


        return view('customedTransaction.view-failed-uploads', $data);
    }
    
     public function failedTransactions(Request $request)
    {

       if (URL::previous() !== URL::current()) {
            $request->session()->forget('transactionType');
        }
        $data['transactionType'] = $request->input('transactionType');
        if ($data['transactionType'] == '') {
            $data['transactionType'] = Session::get('transactionType');
        }
        Session(['transactionType' => $data['transactionType']]);

        $data['toDate'] = $request->input('toDate');
        if ($data['toDate'] == "") {
            $data['toDate'] = date("Y-m-d");
        }

        $data['fromDate'] = $request->input('fromDate');
        if ($data['fromDate'] == "") {
            $data['fromDate'] = date("Y") . '-01-01';
        }
       
       
        if (isset($_POST['modify'] ) ) {
            DB::table('automated_record')
            ->where('failed_ref', $request->input('id'))
            ->where('process_status', 2)
            ->update([
                'processed_at' => date('Y-m-d'),
                'process_status' => 0
            ]);
     
        }
        if (isset($_POST['resolveAll'] ) ) {
            DB::table('automated_record')
            ->where('process_status', 2)
            ->update([
                'processed_at' => date('Y-m-d'),
                'process_status' => 0
            ]);
     
        }
        $data['records'] = DB::table('automated_record')
        ->leftJoin('account_charts_sub', 'account_charts_sub.accountno', 'automated_record.account_number')
            ->select(
                DB::raw('sum(`debit`) as debits'),
                DB::raw('COUNT(*) as counts'),
                DB::raw('sum(`credit`) as credits'),
                DB::raw('sum(`fees`) as fees'),
                DB::raw('sum(`bank_charges`) as bank_charges'),
                DB::raw('sum(`agent_commission`) as agent_commission'),
                DB::raw('sum(`bonus`) as bonus'),
                DB::raw('sum(`aggregator_commission`) as aggregator_commission'),
                DB::raw('sum(`aggregator_referral`) as aggregator_referral'),
                DB::raw('sum(`company_commission`) as company_commission'),
                'account_number',
                DB::raw('MAX(`service_provider`) as service_provider'), 
                DB::raw('MAX(`account_name`) as account_name'), 
                DB::raw('MAX(`account_charts_sub`.`chart_id`) as agent_account'),
                DB::raw('MAX(`account_charts_sub`.`id`) as agent_account_sub'),
                 'failed_ref',
                'account_id',
                'formatted_date',
                'transaction_type'
            )
            ->where('process_status', 2)
            ->where('formatted_date', ">=", $data['fromDate'])
            ->where('formatted_date', "<=", $data['toDate'])
            ->groupBy('formatted_date', 'account_id', 'account_number', 'transaction_type', 'failed_ref')
            ->get();
         

        return view('customedTransaction.process_uploads_failed', $data);
    }
    
     public function detailsfailedTransactions(Request $request, $id)
    {

       
        $data['records'] = DB::table('automated_record')
        ->leftJoin('account_charts_sub', 'account_charts_sub.accountno', 'automated_record.account_number')
            ->select(
                DB::raw('sum(`debit`) as debits'),
                DB::raw('COUNT(*) as counts'),
                DB::raw('sum(`credit`) as credits'),
                DB::raw('sum(`fees`) as fees'),
                DB::raw('sum(`bank_charges`) as bank_charges'),
                DB::raw('sum(`agent_commission`) as agent_commission'),
                DB::raw('sum(`bonus`) as bonus'),
                DB::raw('sum(`aggregator_commission`) as aggregator_commission'),
                DB::raw('sum(`aggregator_referral`) as aggregator_referral'),
                DB::raw('sum(`company_commission`) as company_commission'),
                'account_number',
                DB::raw('MAX(`service_provider`) as service_provider'), 
                DB::raw('MAX(`account_name`) as account_name'), 
                DB::raw('MAX(`account_charts_sub`.`chart_id`) as agent_account'),
                DB::raw('MAX(`account_charts_sub`.`id`) as agent_account_sub'),
                
                'account_id',
                'formatted_date',
                'transaction_type',
                'reference_number'
            )
            ->where('process_status', 2)
            ->where('failed_ref',  $id)
            ->groupBy('formatted_date', 'account_id', 'account_number', 'transaction_type', 'reference_number')
            ->get();
         

        return view('customedTransaction.details_process_uploads_failed', $data);
    }
    
     public  function data_record1($transactionType, $batch)
    { 

            $records = DB::select("SELECT 
            SUM(debit) AS debits,
            SUM(credit) AS credits,
            SUM(fees) AS fees,
            SUM(bank_charges) AS bank_charges,
            SUM(agent_commission) AS agent_commission,
            SUM(bonus) AS bonus,
            SUM(aggregator_commission) AS aggregator_commission,
            SUM(aggregator_referral) AS aggregator_referral,
            SUM(company_commission) AS company_commission,
            account_number,
            MAX(service_provider) AS service_provider,
            MAX(account_name) AS account_name,
            MAX(account_charts_sub.chart_id) AS agent_account,
            MAX(account_charts_sub.id) AS agent_account_sub,
            account_id,
            formatted_date,
            transaction_type
        FROM 
            automated_record
        LEFT JOIN 
            account_charts_sub ON account_charts_sub.accountno = automated_record.account_number
        WHERE 
            process_status = 0
            AND group_batch = '$batch' 
        GROUP BY 
            formatted_date, account_id, account_number, transaction_type, service_provider
        ");
        return $records;
    }

}
